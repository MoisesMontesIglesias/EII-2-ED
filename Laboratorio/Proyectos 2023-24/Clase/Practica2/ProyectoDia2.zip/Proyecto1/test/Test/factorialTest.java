package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class factorialTest {

	@Test
	public void test() {
		assertEquals(Algoritmos.iterativoFactorial(3),6);
		assertEquals(Algoritmos.recursivoFactorial(3),6);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativoFactorial(0),1);
		assertEquals(Algoritmos.recursivoFactorial(0),1);
	}
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativoFactorial(10),3628800);
		assertEquals(Algoritmos.recursivoFactorial(10),3628800);
	}

}
