package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class potenciaTest {

	
	@Test
	public void test1() {
		assertEquals(Algoritmos.iterativoPotencia(3,3),27);
		assertEquals(Algoritmos.recursivoPotencia(3,3),27);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativoPotencia(0,0),1);
		assertEquals(Algoritmos.recursivoPotencia(0,0),1);
	}
	
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativoPotencia(6,6),46656);
		assertEquals(Algoritmos.recursivoPotencia(6,6),46656);
	}
}
