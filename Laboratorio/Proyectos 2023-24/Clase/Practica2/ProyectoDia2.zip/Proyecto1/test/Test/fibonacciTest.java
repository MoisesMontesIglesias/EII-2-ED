package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class fibonacciTest {

	@Test
	public void test1() {
		assertEquals(Algoritmos.iterativoFibonacci(3),2);
		assertEquals(Algoritmos.iterativoFibonacci(3),2);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativoFibonacci(0),0);
		assertEquals(Algoritmos.iterativoFibonacci(0),0);
	}
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativoFibonacci(10),55);
		assertEquals(Algoritmos.iterativoFibonacci(10),55);
	}

}
