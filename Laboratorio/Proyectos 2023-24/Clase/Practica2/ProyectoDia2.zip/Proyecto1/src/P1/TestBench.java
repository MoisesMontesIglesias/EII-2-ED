package P1;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TestBench {
	
	public static Object testAlgorithm(String className, String methodName, int n) {
		Object obj = null;
		try {
			obj = Class.forName(className).getDeclaredConstructor().newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Method method = null;
		try {
			method = obj.getClass().getMethod(methodName, int.class);
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			return method.invoke(obj, n);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return method;
		
	}
	
	public static void test(String output, int times, int startN, int endN,String className,
			String methodName) throws IOException{
		FileWriter writer = new FileWriter(output);
		for(int workLoad = startN ; workLoad < endN ; workLoad++){
			long startTime = System.currentTimeMillis();
			for(int time = 0 ; time < times ; time++) 
				testAlgorithm(className, methodName, workLoad);
				long finalTime = System.currentTimeMillis();
			writer.write(workLoad + "; " + ((finalTime - startTime) /times + "\n"));
		}
		writer.close();
	}

	
}
