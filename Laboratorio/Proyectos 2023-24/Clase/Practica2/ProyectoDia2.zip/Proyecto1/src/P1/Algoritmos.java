package P1;

public class Algoritmos {
	
	private static int a;
	private static final long SLEEP_TIME = 250;
	
	public static int doNothing() {
		try {
			Thread.sleep(SLEEP_TIME);
			return 0;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
	
	
	public static int iterativoFactorial(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		a = 1;
		for (int i = 2; i < n+1; i++) {
			a *= i;
		}

		return a;
	}
	
	public static int iterativoFibonacci(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if(n == 0) {
			return 0;
		}	
		int fibo1 = 1;
		int fibo2 = 1;
		for (int i = 2; i < n; i++) {
			fibo2 = fibo1 + fibo2;
			fibo1 = fibo2 - fibo1;
		}
		return fibo2;
	}
	
	public static int iterativoPotencia(int base, int exponente) {
		if (base < 0 || exponente < 0) {
			throw new IllegalArgumentException("Introduce ambos n�meros positivos");
		}
		if (exponente == 0) {
			return 1;
		}	
		return (int) Math.pow(base, exponente);
	}
	
	public static int recursivoFactorial(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if(n == 0) {
			return 1;
		} else {
			return n*recursivoFactorial(n-1);
		}
	}
	
	public static int recursivoPotencia(int base, int exponente) {
		if (base < 0 || exponente < 0) {
			throw new IllegalArgumentException("Introduce ambos n�meros positivos");
		}
		if (exponente == 0) {
			return 1;
		}else {
			return base * recursivoPotencia(base, exponente-1);
		}
		
	}
	
	public static int recursivoFibonacci(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if (n == 0) {
			return 0;
		} else if(n == 1) {
			return 1;
		}
		return recursivoFibonacci(n-1) + recursivoFibonacci(n-2);
	}
	
	public static void lineal(int n) {
		for (int i = 0; i < n; i++) {
			doNothing();
		}
	}
	
}
