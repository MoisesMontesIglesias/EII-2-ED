package P3.BST;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class arbolesTest {

	@Test
	public void test() {
		BSTree<Integer> arbol = new BSTree<Integer>();
		assertTrue(arbol.addNode(5));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(8));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(3));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(7));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(9));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(2));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(4));
		System.out.println(arbol.toString());
		assertTrue(arbol.addNode(1));
		System.out.println(arbol.toString());
		
		
		
	}

}
