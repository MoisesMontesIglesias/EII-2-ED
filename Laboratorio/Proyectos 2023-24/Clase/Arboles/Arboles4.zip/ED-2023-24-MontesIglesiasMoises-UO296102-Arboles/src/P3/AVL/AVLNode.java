package P3.AVL;

/** 
	* @author Prodesores ED (Español) 
	* @version 2023-24 
	*/ 
	public class AVLNode <T extends Comparable<T>>{ //Hereda de la clase comparable a la qe le paso cualquier objeto
	//T es un objeto
	private T info; 
	private AVLNode<T> left; 
	private AVLNode<T> right;
	private int bf;
	private int altura;
	 
	/** 
	* Se le pasa un objeto comparable 
	* @param node La informaci�n para el nodo
	*/ 
	public AVLNode (T node) {
		this.info = node;
		this.left = null;
		this.right = null;
		this.bf = 0;
		this.setAltura(0);
	}  
	 
	/** 
	* Se le pasa la información que se quiere meter en el nodo 
	*/ 
	protected void setInfo(T node) {
		info = node;
	}
	 
	/** 
	* Devuelve la información que almacena el nodo 
	*/ 
	public T getInfo() {
		return info;
	}
	 
	 
	/** 
	* Se le pasa el nodo que se quiere enlazar en el subárbol izquierdo 
	*/ 
	protected void setLeft(AVLNode<T> node){
		left = node;
	}
	 
	 
	/** 
	* Se le pasa el nodo que se quiere enlazar en el subárbol derecho 
	*/ 
	protected void setRight(AVLNode<T> node){
		right = node;
	} 
	 
	 
	/** 
	* Devuelve el subárbol izquierdo 
	*/ 
	public AVLNode<T> getLeft () {
		return left;
	} 
	 
	 
	/** 
	* Devuelve el subárbol derecho 
	*/ 
	public AVLNode<T> getRight () {
		return right;
	} 
	 
	 
	/**
		 * Metodo que devuelve una cadena con la información del BTSNode
		 * 
		 * @return  Un String que representa al objeto BTSNode
		 */
	public String toString() { 
		return info.toString() + ":BF=" + getBF(); 
	}

	public int getBF() {
		return bf;
	}

	public void setBF(int bF) {
		bf = bF;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}  
	
	public void updateBFHeight() {
		int HD = 0; //Altura derecha (altura del hijo derecho + 1)
		int HI = 0; //Altura izquierda (altura del hijo izquierdo + 1)
		if(getRight() != null) { //Si hay en la derecha --> obtener altura 
			HD = getRight().getAltura() + 1;
		}
		if(getLeft() != null) { //Si hay en la izquierda --> obtener altura 
			HI = getLeft().getAltura() + 1;
		}
		setBF(HD - HI); //Actualizar valor de balance
		setAltura(Integer.max(HD, HI)); //actualizar valor de la altura
	}
	
	
} 