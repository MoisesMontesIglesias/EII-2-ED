package P3.AVL;

/**
	* @author Prodesores ED (Español)
	* @version 2023-24 distribuible
	*/
	public class AVLTree <T extends Comparable<T>>{
	
	/**
	 * El nodo raiz del arbol. DEBE SER PRIVADO PARA NO PERDER EL ARBOL
	 */
	private AVLNode<T> raiz;
	
	/**
	 * Constructor por defecto para la clase BSTree
	 */
	public AVLTree() {
		raiz = null;
	}
	
	/**
	 * getter del nodo raiz del arbol
	 */
	protected AVLNode<T> getRoot() {
		return raiz;
	}
	
	/**
	 * setter del nodo raiz del arbol
	 */
	protected void setRoot(AVLNode<T> nodo) {
		raiz = nodo;
	}
	
	
	/**
	 * Se le pasa el objeto comparable que hay que insertar
	 * devuelve true si lo inserta
	 * Si ya existe, no lo inserta y devuelve false (implementado mas tarde). 
	 * Si recibe un nodo nulo, no lo inserta y lanza una NullPointerException
	 */
	public boolean addNode(T clave) {
		if(clave == null) {
			throw new NullPointerException();
		}
		if(searchNode(clave) != null) {
			return false;
		}
		if (getRoot()==null) {
			setRoot(new AVLNode<T>(clave));
		} else {
			setRoot(addNodeR(getRoot(), clave));
		}
		return true;
	}
	
	
	private AVLNode<T> addNodeR(AVLNode<T> actual, T node) {
		if (node.compareTo(actual.getInfo()) < 0) {
			if(actual.getLeft() != null) {
				actual.setLeft(addNodeR(actual.getLeft(), node));
			}else {
				actual.setLeft(new AVLNode<T>(node));
			}
		} else {
			if(actual.getRight() != null) {
				actual.setRight(addNodeR(actual.getRight(), node));
			}else {
				actual.setRight(new AVLNode<T>(node));
			}
		}
		return updateBFHeightBalanceo(actual);
	}
	
	/**
	 * Este m�todo reorganiza el sub�rbol del nodo que se le pasa como par�metro si es
	 *	necesario (cuando su |BF| es >1) y lo devuelve una vez se han actualizado su altura y
	 *	factor de balance
	 * @param nodo
	 * @return
	 */
	private AVLNode<T> updateBFHeightBalanceo(AVLNode<T> nodo){
		nodo.updateBFHeight();
		if(nodo.getBF() == 2) {
			if(nodo.getRight().getBF() >= 0) {
				nodo = singleRightRotation(nodo);
			} else {
				nodo = doubleRightRotation(nodo);
			}
		} else if(nodo.getBF() == -2) {
			if(nodo.getLeft().getBF() <= 0) {
				nodo = singleLeftRotation(nodo);
			} else {
				nodo = doubleLeftRotation(nodo);
			}
		}
		return nodo;
		
	}
	
	/**
	 * M�todo que se encarga de realizar una rotaci�n simple a la izquierda sobre el sub�rbol
	 * del nodo pasado como par�metro y devuelve el nodo resultante

	 * @param nodo
	 * @return
	 */
	private AVLNode<T> singleLeftRotation(AVLNode<T> nodo){
		AVLNode<T> aux = nodo.getLeft(); //aux = sub�rbol izquierdo del nodo N
		nodo.setLeft(aux.getRight()); //nodo N por la izquierda = sub�rbol derecho de aux
		nodo.updateBFHeight(); //Se debe actualizar el nodo cada vez que se cambia el valor de una rama
		aux.setRight(nodo); //aux por la derecha = nodo N
		aux.updateBFHeight(); //Idem
		return aux;
		
	}

	/**
	 * M�todo que se encarga de realizar una rotaci�n simple a la derecha sobre el sub�rbol del
	 * nodo pasado como par�metro y devuelve el nodo resultante
	 * @param nodo
	 * @return
	 */
	private AVLNode<T> singleRightRotation(AVLNode<T> nodo){
		AVLNode<T> aux = nodo.getRight(); //aux = sub�rbol derecho del nodo N
		nodo.setRight(aux.getLeft()); //nodo N por la derecha = sub�rbol izquierdo de aux
		nodo.updateBFHeight(); //Se debe actualizar el nodo cada vez que se cambia el valor de una rama
		aux.setLeft(nodo); //aux por la izquierda = nodo N
		aux.updateBFHeight(); //Idem
		return aux;
		
	}
	
	/**
	 * M�todo que se encarga de realizar una rotaci�n doble a la izquierda sobre el sub�rbol del
	 * nodo pasado como par�metro y devuelve el nodo resultante

	 * @param nodo
	 * @return
	 */
	private AVLNode<T> doubleLeftRotation(AVLNode<T> nodo) {
		nodo.setLeft(singleRightRotation(nodo.getLeft())); //RSD sobre el sub�rbol izquierdo de N
		return singleLeftRotation(nodo); //RSI sobre el nodo N
	}
	
	/**
	 * M�todo que se encarga de realizar una rotaci�n doble a la derecha sobre el sub�rbol del
	 * nodo pasado como par�metro y devuelve el nodo resultante
	 * @param nodo
	 * @return
	 */
	private AVLNode<T> doubleRightRotation(AVLNode<T> nodo) {
		nodo.setRight(singleLeftRotation(nodo.getRight())); //RSI sobre el sub�rbol derecho de N
		return singleRightRotation(nodo); //RSD sobre el nodo N
	}
	

	/**
	* Se le pasa un objeto comparable que se busca
	* Devuelve el objeto encontrado que cumple que es "equals" con el
	* buscado, null si no lo encuentra por cualquier motivo
	*/
	public AVLNode<T> searchNode(T node) {;
		if(node == null || getRoot() == null) {
			return null;
		}
		return recursiveSearch(node,getRoot());
	}
	
	/**
	 * Busqueda recursiva
	 * @param node
	 * @param raiz
	 * @return BSTNode
	 */
	private AVLNode<T> recursiveSearch(T node, AVLNode<T> actual) {
		if(node == null || actual == null) {
			return null;
		}
		else if(actual.getInfo().equals(node)) {
			return actual;
		}
		else if(actual.getInfo().compareTo(node) > 0) {
			//Si es menor por la izquierda
			return recursiveSearch(node, actual.getLeft());
		} else {
			//Si es mayor por la derecha
			return recursiveSearch(node, actual.getRight());
		}
	}
	
	/**
	* Se le pasa el objeto que se quiere borrar que coincida con equals
	* Si recibe un nodo nulo, lanza una NullPointerException
	* Devuelve true si lo ha borrado, false caso contrario
	*/
	public boolean removeNode (T node){
		if(node == null) {
			throw new NullPointerException();
		}
		if(getRoot() == null) {
			return false;
		}
		if(searchNode(node) != null) {
			setRoot(removeNodeR(getRoot(), node));
			return true;
		}
		
		return false;
	}
	
	private AVLNode<T> removeNodeR(AVLNode<T> actual, T info){
		if(info.compareTo(actual.getInfo()) == 0) {
			if(actual.getLeft() == null && actual.getRight() == null) {
				return null;
			} else if(actual.getLeft() == null || actual.getRight() == null) {
				if(actual.getLeft() == null) {
					return actual.getRight();
				} else {
					return actual.getLeft();
				}
			} else {
				actual.setInfo(getMaximo(actual.getLeft()));
				actual.setLeft(removeNodeR(actual.getLeft(), actual.getInfo()));
			}
		} else if(info.compareTo(actual.getInfo()) < 0) {
			actual.setLeft(removeNodeR(actual.getLeft(), info));
		} else {
			actual.setRight(removeNodeR(actual.getRight(), info));
		}
		return updateBFHeightBalanceo(actual);
	}
	
	private T getMaximo(AVLNode<T> actual) {
		return recursiveGetMaximo(actual);
	}

	private T recursiveGetMaximo(AVLNode<T> actual) {
		if(actual.getRight() == null) {
			return actual.getInfo();
		}
		return recursiveGetMaximo(actual.getRight());
	}

	/**
	* Genera un String con el recorrido en pre-orden (izquierda-derecha)
	* (toString de los nodos separados por tabuladores)
	*/
	public String preOrder() {
		String path = "";
		return recursivePreOrder(getRoot(), path).strip();
	}
	

	private String recursivePreOrder(AVLNode<T> actual, String path) {
		if(actual == null) {
			return "";
		}
		path = actual.toString() + "\t" + recursivePreOrder(actual.getLeft(), path) + 
				recursivePreOrder(actual.getRight(), path);
		return path;
	}

	/**
	* Genera un String con el recorrido en post-orden (izquierda-derecha)
	* (toString de los nodos separados por tabuladores)
	*/
	public String postOrder() {
		String path = "";
		return recursivePostOrder(getRoot(), path).strip();
	}


	private String recursivePostOrder(AVLNode<T> actual, String path) {
		if(actual == null) {
			return "";
		}
		path = recursivePostOrder(actual.getLeft(), path) + 
				recursivePostOrder(actual.getRight(), path) + "\t" + actual.toString();
		return path;
	}

	/**
	* Genera un String con el recorrido en in-orden (izquierda-derecha)
	* (toString de los nodos separados por tabuladores)
	*/
	public String inOrder() {
		String path = "";
		return recursiveInOrder(getRoot(), path).strip();
	}
	
	private String recursiveInOrder(AVLNode<T> actual, String path) {
		if(actual == null) {
			return "";
		}
		path = recursiveInOrder(actual.getLeft(), path) + actual.toString()  + "\t" + 
				recursiveInOrder(actual.getRight(), path);
		return path;
	}

	
	public String toString() {
		return tumbarArbol(getRoot(), 0);
	}
	
	/**
	* Genera un String con el arbol "tumbado" (la raiz a la izquierda y las ramas hacia la derecha)
	* Es un recorrido InOrden-Derecha-Izquierda, tabulando para mostrar los distintos niveles
	* Utiliza el toString de la informacion almacenada
	*
	* @param p La raiz del arbol a mostrar tumbado
	* @param esp El espaciado en numero de tabulaciones para indicar la profundidad
	* @return El String generado
	*/
	protected String tumbarArbol(AVLNode<T> p, int esp) {
	StringBuilder cadena = new StringBuilder();
	
		if (p != null) {
			cadena.append(tumbarArbol(p.getRight(), esp + 1));
			for (int i = 0; i < esp; i++)
				cadena.append("\t");
			cadena.append(p + "\n");
			cadena.append(tumbarArbol(p.getLeft(), esp + 1));
		}
		return cadena.toString();
	}
	
//****************************************	EJERCICIOS EXTRA	*********************************************
	
	/**
	 * El padre de un info que se le pasa por parametro
	 */
	public AVLNode<T> getPadre(T info){
		if(searchNode(info) == null || info == null) {
			throw new NullPointerException("Ese nodo no existe");
		}
		return recursiveGetPadre(getRoot(), info);
		
	}

	private AVLNode<T> recursiveGetPadre(AVLNode<T> actual, T info) {
		if (info.compareTo(actual.getInfo()) < 0) {
			actual.setLeft(recursiveGetPadre(actual.getLeft(), info));
		} else if (info.compareTo(actual.getInfo()) > 0) {
			actual.setRight(recursiveGetPadre(actual.getRight(), info));
		}
		return actual;
	}
	
	/**
	 * N�mero de aristas entre dos nodos que se les pase por parametro
	 */
	
	
}