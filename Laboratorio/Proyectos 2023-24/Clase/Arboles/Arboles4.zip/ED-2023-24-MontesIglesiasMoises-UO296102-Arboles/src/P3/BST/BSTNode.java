package P3.BST;


	/** 
	* @author Prodesores ED (Español) 
	* @version 2023-24 
	*/ 
	public class BSTNode <T extends Comparable<T>>{ //Hereda de la clase comparable a la qe le paso cualquier objeto
	//T es un objeto
	private T info; 
	private BSTNode<T> left; 
	private BSTNode<T> right; 
	 
	 
	/** 
	* Se le pasa un objeto comparable 
	* @param node La informaci�n para el nodo
	*/ 
	public BSTNode (T node) {
		this.info = node;
		this.left = null;
		this.right = null;
	}  
	 
	/** 
	* Se le pasa la información que se quiere meter en el nodo 
	*/ 
	protected void setInfo(T node) {
		info = node;
	}
	 
	/** 
	* Devuelve la información que almacena el nodo 
	*/ 
	public T getInfo() {
		return info;
	}
	 
	 
	/** 
	* Se le pasa el nodo que se quiere enlazar en el subárbol izquierdo 
	*/ 
	protected void setLeft(BSTNode<T> node){
		left = node;
	}
	 
	 
	/** 
	* Se le pasa el nodo que se quiere enlazar en el subárbol derecho 
	*/ 
	protected void setRight(BSTNode<T> node){
		right = node;
	} 
	 
	 
	/** 
	* Devuelve el subárbol izquierdo 
	*/ 
	public BSTNode<T> getLeft () {
		return left;
	} 
	 
	 
	/** 
	* Devuelve el subárbol derecho 
	*/ 
	public BSTNode<T> getRight () {
		return right;
	} 
	 
	 
	/**
	 * Metodo que devuelve una cadena con la información del BTSNode
	 * 
	 * @return  Un String que representa al objeto BTSNode
	 */
	public String toString() { 
		return info.toString(); 
	}  
} 