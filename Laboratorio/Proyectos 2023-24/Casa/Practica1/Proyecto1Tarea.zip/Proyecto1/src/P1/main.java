package P1;

public class main {

	public static void main(String[] args) {
		Algoritmos.iterativoFibonacci(4);
		Algoritmos.recursivoFibonacci(4);
		Algoritmos.iterativoFactorial(4);
		Algoritmos.recursivoFactorial(4);
		Algoritmos.iterativoPotencia(4,4);
		Algoritmos.recursivoPotencia(4,4);
	}

}
