package p2;

import java.text.DecimalFormat;

/**
 * Clase grafos - matrices de adyacencias
 * 
 * @author Paula Alguacil Fern�ndez (uo294621)
 * @version 25/09/2023
 *
 */
public class Grafos<T> {
	
	private double[][] weights;	// Pesos de la arista
	private boolean[][] edges;	// Matriz de aristas
	private T[] nodes;	// Nodos: Lista de nodos
	private int size; 	//Tama�o del grafo (n�mero de elementos)

	/**
	 * Constructor
	 * 
	 * @param dimension, int con la dimension del grafo
	 */
	@SuppressWarnings("unchecked")
	public Grafos (int dimension) {
		nodes = (T[]) new Object[dimension];
		this.weights = new double[dimension][dimension];
		this.edges = new boolean[dimension][dimension];
		this.size = 0;
	}

	/**
	 *  Devuelve el tama�o del grafo
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * Inserta un nuevo nodo que se le pasa como par�metro
	 * - Si ya existe, no lo inserta y devuelve false
	 * - Si recibe un nodo nulo, no lo inserta y lanza una NullPointerException
	 * - Si no cabe, no lo inserta y lanza una FullStructureException
	 */
	public boolean addNode(T node) {
		if (node == null) {
			throw new NullPointerException();
		}
		if(node != null && getSize() >= nodes.length) {
			throw new FullStructureException(node);
		}
		if(existsNode(node)) {
			return false;
		}
		for(int i = 0; i < getSize(); i++) {
				edges[i][size] = false;
				edges[size][i] = false;
				weights[i][size] = 0;
				weights[size][i] = 0;
		}
		nodes[size] = node;
		size++;
		return true;
	}
	
	/**
	 * Devuelve la posici�n del nodo pasado como par�metro dentro del vector 
	 * de nodos y -1 si el nodo no existe o es null
	 */
	protected int getNode(T node) {
		if (node == null) {
			return -1;
		}
		for(int i = 0; i < getSize(); i++) {
			if(nodes[i].equals(node)) {
				return i;
			} 
		}
		return -1;
	}
	
	/**
	 * Indica si existe (true) o no (false) el nodo en el grafo 
	 */
	public boolean existsNode(T node) {
		if(getNode(node) != -1) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Si existe, borra el nodo deseado del vector de nodos as� como
	 * las aristas en las que forma parte y devuelve true
	 * - Si el nodo no existe devuelve false
	 * - Si recibe un nodo nulo, lanza una NullPointerException
	 */
	public boolean removeNode(T node) {
		if(node == null) {
			throw new NullPointerException();
		}
		if(existsNode(node) == false) {
			return false;
		}
		int pos = getNode(node);
		size--;
		nodes[pos] = nodes[size];
		for(int i = 0; i < getSize(); i++) {
			edges[i][pos] = edges[size][i];
			edges[pos][i] = edges[i][size];
			weights[i][pos] = weights[size][i];
			weights[pos][i] = weights[i][size];
		}
		return true;
	}
	
	/**
	 * Inserta una arista con el peso indicado (> 0) entre dos nodos, 
	 * uno origen y otro destino
	 * - Devuelve true si la inserta
	 * - Devuelve falso si ya existe el arco (arista)
	 * - Lanza una excepcion ElementNotPresentException si no existe el nodo origen o destino
	 * - Lanza una IllegalArgumentException si el peso es invalido
	 */
	public boolean addEdge(T source, T target, double weight) {
		int initPos = getNode(source);
		int finalPos = getNode(target);
		if(existsNode(source) == false) {
			throw new ElementNotPresentException(source);
		}
		if(existsNode(target) == false) {
			throw new ElementNotPresentException(target);
		}
		if(weight < 0) {
			throw new IllegalArgumentException();
		}
		if(existsEdge(source, target) == false) {
			edges[initPos][finalPos] = true;
			weights[initPos][finalPos] = weight;
			return true;
		} else if(existsEdge(source, target) == true) {
			return false;
		}
		return false;
	}
	
	/**
	 * Devuelve true si existe una arista entre los nodos origen
	 * y destino, false en caso contrario o no existen los nodos
	 */
	public boolean existsEdge(T source, T target) {
		int initPos = getNode(source);
		int finalPos = getNode(target);
		if(existsNode(source) == false || existsNode(target) == false) {
			return false;
		} else {
			return edges[initPos][finalPos];
		}
	}
	
	/**
	 * Devuelve el peso de la arista que conecta dos nodos 
	 * - Si los nodos source o target no existen, lanza una excepci�n de tipoElementNotPresentException
	 * - Si tanto source como target existen, pero la arista a eliminar no, devuelve -1
	 */
	public double getEdge(T source, T target) {
		int initPos = getNode(source);
		int finalPos = getNode(target);
		if(existsNode(source) == false) {
			throw new ElementNotPresentException(source);
		}
		if(existsNode(target) == false) {
			throw new ElementNotPresentException(target);
		}
		
		if(existsEdge(source, target) == false) {
			return -1;
		} 
		return weights[initPos][finalPos];
	}
	
	/**
	 * Borra la arista del grafo que conecta dos nodos
	 * - Si la arista existe, se borra y devuelve true
	 * - Si los nodos source o target no existen, lanza una excepci�n de tipo ElementNotPresentException
	 * - Si tanto source como target existen, pero la arista a eliminar no, devuelve false
	 */
	public boolean removeEdge(T source , T target) {
		if(existsNode(source) == false) {
			throw new ElementNotPresentException(source);
		}
		if(existsNode(target) == false) {
			throw new ElementNotPresentException(target);
		}
		if(existsEdge(source, target) == true) {
			removeEdge(source, target);
			return true;
		}
		if(existsEdge(source, target) == false) {
			return false;
		}
		int init = getNode(source);
		int fin = getNode(target);
		edges[init][fin] = false;
		weights[init][fin] = 0;
		return true;
	}
	
	/**
	 * M�todo que devuelve un DijkstraDataClass con los vectores D y P correspondientes si se
	 * aplica o null si no se puede aplicar
	 */
	public DijkstraDataClass dijkstra(T source) {
//		DijkstraDataClass djk;
		boolean s[] = new boolean[getSize()];
		
		if(source == null) {
			throw new NullPointerException();
		}
		if(existsNode(source) == false) {
			return null;
		} else {
			int pos = getNode(source);
			int[] p = p();
			double[] d = d(source);
			s[getNode(source)] = true;
		
			int w = getPivote(d,s);
			while(w != -1) {
				s[w] = true;
			}
			
//			for(int i = 0; i < getSize(); i++) {
//				if(edges[w][i] && djk.getdDijkstra()[w] + weights[w][i] < djk.getdDijkstra()[i]) {
//					djk.getdDijkstra()[i] = djk.getdDijkstra()[w] + weights[w][i];
//					djk.getpDijkstra()[i] = w;
//				}
//			}
			
		return new DijkstraDataClass(getSize(), pos,  d, p);
		}
	}
	
	/**
	 * M�todo que inicializa la matriz p
	 */
	private int[] p() {
		int [] p = new int[getSize()];
		for(int i = 0; i < getSize(); i++) {
			p[i] = -1;
		}
		return p;
	}
	
	/**
	 * M�todo que inicializa la matriz d
	 */
	private double[] d(T source) {
		double [] d = new double[getSize()];
		int pos = getNode(source);
		for(int i = 0; i < getSize(); i++) {
			if(existsEdge(source,nodes[i]) == true) {
				d[i] = weights[getNode(source)][i];
			} else if(pos == i) {
				d[i] = 0.0;
			} else {		
				d[i] = Double.POSITIVE_INFINITY;
			}
		}
		return d;
	}
	
	
	/**
	 * Devuelve la posici�n del nodo cuyo valor en la matriz D es la menor
	 */
	private int getPivote(double[] d, boolean[] s) {
		int pivote = 0;
		double menor = Double.POSITIVE_INFINITY;
		for (int i = 0; i < getSize(); i++) {
			if (s[i] == false) {
				if (d[i] < menor) {
					pivote = getNode(nodes[i]);
					menor = d[i];
				}
			}
		}
		return pivote;
	}
	

	
	/**
	 * Imprime el grafo
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		String cadena = "";
		cadena += "NODOS\n";
		for (int i = 0; i < size; i++) {
			cadena += nodes[i].toString() + "\t";
		}
		cadena += "\n\nARISTAS\n";
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				if (edges[i][j])
					cadena += "T\t";
				else
					cadena += "F\t";
			}
			cadena += "\n";
		}
		cadena += "\nPESOS\n";
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				cadena += (edges[i][j] ? df.format(weights[i][j]) : "-") + "\t";
			}
			cadena += "\n";
		}
		return cadena;
	}
}
