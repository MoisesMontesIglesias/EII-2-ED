package P3.Monticulos;

/**
 * @author Profesores ED
 * @version 2023-24 distribuible
 */
 public class EDBinaryHeap<T extends Comparable<T>> implements EDPriorityQueue<T>{
	protected T [] elementos;
	protected int numElementos;

	
	@SuppressWarnings("unchecked")
	public EDBinaryHeap(int numMaxElementos) {
		elementos = (T[]) new Comparable[numMaxElementos];
		numElementos = 0;
	}

	@Override
	public boolean add(T info) {
		if(info == null) {
			throw new NullPointerException();
		}
		if(elementos.length <= numElementos) {
			return false;
		}
		elementos[numElementos] = info;
		filtradoAscendente(numElementos);
		numElementos++;
		return true;
	}

	public int searchElement(T info) {
		if(info == null) {
			throw new NullPointerException();
		}
		for (int i = 0; i < numElementos; i++) {
			if(info.equals(elementos[i])) {
				return i;
			}
		}
		return -1;
	}

	public void cambiarPrioridad() {
		
	}
	
	@Override
	public T poll() {
		if(isEmpty()) {
			return null;
		}
		T sacar = elementos[0];
		numElementos--;
		elementos[0] = elementos[numElementos];
		filtradoDescendente(0);
		return sacar;
	}

	@Override
	public boolean remove(T info) {
		if(info == null) {
			throw new NullPointerException();
		}
		int posicion = searchElement(info);
		if(posicion == -1) {
			return false;
		} 
		numElementos--;
		elementos[posicion] = elementos[numElementos];
		filtradoDescendente(posicion);
		return true;
	}

	@Override
	public boolean isEmpty() {
		if(numElementos != 0) {
			return false;
		}
		return true;
	}

	@Override
	public void clear() {
		numElementos = 0;
	}

	/**  
	 * Devuelve una cadena con la informacion de los elementos que contiene el  
	 * monticulo separados por tabuladores
	*/
	@Override
	public String toString() {
		String path = "";
		for (int i = 0; i < numElementos; i++) {
			path += elementos[i].toString() + "\t";
		};
		return path.strip();
	}

	@Override
	public boolean cambiarPrioridad(int pos, T elemento) {
		return false;
	}
    

    /**
     * Realiza una filtrado ascendente de minimos en el monticulo
     * 
     * Se le pasa el indice del elemento a filtrar
     */
    protected void filtradoAscendente(int posHijo) {
    	int posPadre = (posHijo-1)/2;
    	while(elementos[posPadre].compareTo(elementos[posHijo]) > 0) {
    		T aux = elementos[posPadre];
    		elementos[posPadre] = elementos[posHijo];
    		elementos[posHijo] = aux;
    		posHijo = posPadre;
    		posPadre = (posHijo-1)/2;
    	}
    }

    /**
     * Realiza una filtrado descendente de minimos en el monticulo
     * 
     * Se le pasa el indice del elemento a filtrar
     */
    protected void filtradoDescendente(int posPadre) {
    	if(posPadre == -1) {
    		return;
    	}
    	int menorHijos = getMinHijo(posPadre);
    	if(menorHijos == -1) {
    		return;
    	}
    	while(elementos[menorHijos].compareTo(elementos[posPadre]) < 0) {
    		T aux = elementos[posPadre];
    		elementos[posPadre] = elementos[menorHijos];
    		elementos[menorHijos] = aux;
    		posPadre = menorHijos;
    		menorHijos = getMinHijo(posPadre);
    		if(menorHijos == -1) {
    			break;
    		}
    	}
    }
	
	/**
	 * Metodo que calcula y devuelve la posicion del hijo menor del nodo pasado
	 * como parametro.
	 * 
	 * @param pos  La posicion del nodo padre
	 * @return  La posicion del menor de sus hijos o -1 si no existe ninguno
	 */
	private int getMinHijo(int posPadre) {
		int posHijoIzq = 2*posPadre + 1;
    	int posHijoDer = 2*posPadre + 2;
		if(posHijoIzq >= numElementos) {
			return -1;
		}else if(posHijoDer >= numElementos && posHijoIzq < numElementos)
			return posHijoIzq;
		if(elementos[posHijoIzq].compareTo(elementos[posHijoDer]) <= 0){
			return posHijoIzq;
		} else {
			return posHijoDer;
		}
	}

}
