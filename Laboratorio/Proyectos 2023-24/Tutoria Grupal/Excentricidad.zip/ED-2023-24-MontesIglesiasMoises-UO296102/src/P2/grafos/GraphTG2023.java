package P2.grafos;

import java.text.DecimalFormat;

/**
 * @author Profesores ED 2023
 * @version 2023-24
 */
public class GraphTG2023<T> {
	/**
	 * Constante infinito
	 */
	protected static final double Inf=Double.POSITIVE_INFINITY;
	
	/**
	 * Vector de nodos
	 */
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int size; // numero de elementos en un momento dado
	
	@SuppressWarnings("rawtypes")
	Grafos grafos = new Grafos(getSize());
	
	/**
	 * 
	 * @param tam
	 *            Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphTG2023(int tam) {
		nodes = (T[]) new Object[tam];
		size = 0;
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
	}

	public int getNumMaxNodes() {
		return nodes.length;
	}
	
	protected int getSize() {
		return size;
	}

	protected T[] getNodes() {
		return nodes;
	}

	protected boolean[][] getEdges() {
		return edges;
	}

	protected double[][] getWeights() {
		return weights;
	}

	protected double[][] getWeight() { // para compatibilidad con pruebas ingles
		return getWeights();
	}


	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * 
	 * @param node que es el nodo que se busca
	 * @return la posicion del nodo en el vector, -1 si no se encuentra
	 */
	protected int getNodeEx(T node) {
		for (int i = 0; i < getSize(); i++) {
			if (nodes[i].equals(node)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Inserta un nuevo nodo que se le pasa como parametro.
	 * Siempre lo inserta, no se controlan casos en que no lo pueda hacer
	 * 
	 * @param node el nodo que se quiere insertar
	 * @return true siempre
	 */
	public boolean addNodeEx(T node) {
		nodes[size] = node;
		for (int i = 0; i <= getSize(); i++) {
			edges[size][i] = false;
			edges[i][size] = false;
		}
		size++;
		return true;
	}


	/**
	 * Inserta una arista entre dos nodos con el peso indicado 
	 * Devuelve true siempre
	 * No comprueba nada. 
	 * @param source
	 *            nodo origen
	 * @param target
	 *            nodo destino
	 * @param edgeWeight
	 *            peso de la arista
	 * @return true siempre
	 */
	public boolean addEdgeEx(T source, T target, double edgeWeight) {
		int posOrigen = getNodeEx(source);
		int posDestino = getNodeEx(target);
		edges[posOrigen][posDestino] = true;
		weights[posOrigen][posDestino] = edgeWeight;
		return true;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos.
	 * Siempre la borra sin comprobar nada
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return true siempre
	 */
	public boolean removeEdgeEx(T source, T target) {
		int posOrigen = getNodeEx(source);
		int posDestino = getNodeEx(target);
		edges[posOrigen][posDestino] = false;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos.
	 * No comprueba nada...
	 *  
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return El peso de la arista
	 */
	public double getEdgeEx(T source, T target) {
		int posOrigen = getNodeEx(source);
		int posDestino = getNodeEx(target);
		return weights[posOrigen][posDestino];
	}

	/**
	 * @return Devuelve un String con la informacion del grafo usando StringBuilder
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		StringBuilder cadena = new StringBuilder();
		
		cadena.append("NODES\n");
		for (int i = 0; i < size; i++) {
			cadena.append(nodes[i].toString() + "\t");
		}
		cadena.append("\n\nEDGES\n");
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				if (edges[i][j])
					cadena.append("T\t");
				else
					cadena.append("F\t");
			}
			cadena.append("\n");
		}
		cadena.append("\nWEIGHTS\n");
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {

				cadena.append((edges[i][j]?df.format(weights[i][j]):"-") + "\t");
			}
			cadena.append("\n");
		}
	
		return cadena.toString();
	}
	
	/**
	 * Devuelve la excentricidad del nodo que se le pasa por par�metro. 
	 * Si el nodo es null lanza NullPointerException. 
	 * Si el nodo no existe devuelve -1.
	 * @param element
	 * @return
	 */
	public double excentricidad(T element) {
		if(element == null) {
			throw new NullPointerException();
		}
		grafos.floyd();
		double[] excent = excentrico(element);
		double j = Double.POSITIVE_INFINITY;
		for (int i = 0; i < excent.length; i++) {
			if(excent[i] < j) {
				j = excent[i];
			}
		}
		return j;
	}
	
	private double[] excentrico(T element) {
		double[] excent = new double[grafos.getSize()];
		for (int i = 0; i < grafos.getSize(); i++) {
			double s = 0;
			if(grafos.getAFloyd()[i][getNodeEx(element)] == Double.POSITIVE_INFINITY) {
				s = Double.POSITIVE_INFINITY;
			}
			else if(grafos.getAFloyd()[i][getNodeEx(element)] > s) {
				s = grafos.getAFloyd()[i][getNodeEx(element)];
			}
			excent[i] = s;
		}
		return excent;
	}
	
	/**
	 * Devuelve la posici�n del nodo que es centro de un grafo
	 * @return
	 */
	public int centroGrafo() {
		grafos.floyd();
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				if(grafos.getPFloyd()[i][j] == 1) {
					return grafos.getPFloyd()[i][j];
				}
			}
		}
		return grafos.getPFloyd()[0][0];
	}
	
	/**
	 * Devuelve la longitud del camino m�s corto
	 * entre el nodo origen y destino. Si alguno de los 
	 * nodos no existe o es null, devuelve -1
	 * @param origen
	 * @param destino
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public double shortestPathLength(T origen, T destino) {
		return grafos.minCostPath(origen, destino);
	}
	
	/**
	 * Devuelve true si el grafo contiene ciclos, 
	 * false en caso contrario.
	 * @return
	 */
	public boolean containsCycles() {
		if(null == null) {
			return true;
		}
		return false;
	}
	
	
}
