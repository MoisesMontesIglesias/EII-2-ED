package p1Algoritmia;

public class Algorithms {
	private static final long SLEEP_TIME = 1;
	
	// para pruebas de que produce una excepción... 
	// assertThrows(IllegalArgumentException.class, () -> {al.factorial(-1);}); 

	public static void doNothing() {
		try {
			Thread.sleep(SLEEP_TIME);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
//----------------------------	Métodos con 1 solo parámetro	--------------------------------------//
// Tener en cuenta que todos los métodos tienen el doNothing() comentado para probar las pruebas
// realizadas en el AlgorithmsTest ya que los tiempos ya salen medidos en los .txt
	
	/**
	 * Algoritmo con una complejidad temporal lineal 
	 * @param n		Tamaño del bucle
	 */
	public void linear (int n) {
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		for (int i = 0; i < n; i++) {
			//doNothing();
		}
	} 
	
	/**
	 * Algoritmo con una complejidad temporal cuadrática 
	 * @param n		Tamaño del bucle
	 */
	public void cuadratic(int n) {
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				//doNothing();
			}
		}
	}
	
	/**
	 * Algoritmo con una complejidad temporal cúbica 
	 * @param n		Tamaño del bucle
	 */
	public void cubic(int n) {
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				for (int k = 0; k < n; k++) {
					//doNothing();
				}
			}
		}
	}
	
	/**
	 * Algoritmo con una complejidad temporal logarítmica en cualquier base
	 * @param n		Tamaño del bucle
	 */
	public void logarithmic(int n) {
		if (n<0)
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n);
		while (n > 0) {
			//doNothing();
			n /= 2;
		}
	}
	
	/**
	 * Calcula el factorial de n>=0 de forma recursiva
	 * @param n		Tamaño del problema
	 * @return		Valor del factorial
	 */
	public long factorial (int n) { 
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		//doNothing();
		if(n!=0) {
			return n * factorial(n-1); //Si es el caso general
		}
		return 1; //Si es el caso base
	} 
	
	/**
	 * Calcula el termino n-esimo teniendo en cuenta que el primer término se considera fib(0)=0; y fib(1)=1 
	 * @param n		Tamaño del problema
	 * @return		Resultado del termino n-ésimo
	 */
	public int fibonacci (int n) {
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		//doNothing();
		//Casos base
		if(n == 0) {
			return 0;
		} else if(n == 1) {
			return 1; 
		}
		return fibonacci(n-2) + fibonacci(n-1); //Si es el caso general

	} 
	
	/**
	 * Realiza la iteración de 2 elevado a n
	 * @param n		Valor del exponente
	 * @return		Valor de 2 elevado al exponente
	 */
	public long pow2Iter(int n) {
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		//doNothing();
		long valor = 1;
		for (int i = 0; i < n; i++) {
			doNothing();
			valor *= 2;
		}
		return valor;
	}
	
	/**
	 * Calcula 2 elevado a n de forma recursiva 2^n = 2*2^(n-1) 
	 * @param n		Valor del exponente
	 * @return		Valor de 2 elevado al exponente
	 */
	public long pow2Rec1(int n) {
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		//doNothing();
		if(n == 0) {
			return 1;
		} else {
			return 2*pow2Rec1(n-1);
		}
	} 
	
	/**
	 * Calcula 2 elevado a n de forma recursiva 2^n = 2^(n-1)+2^(n-1)
	 * @param n		Valor del exponente
	 * @return		Valor de 2 elevado al exponente
	 */
	public long pow2Rec2 (int n) {
		if (n<0)
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n);
		//doNothing();
		if(n == 0) {
			return 1;
		}
		return pow2Rec2(n-1) + pow2Rec2(n-1);
	}
	
	/**
	 * Calcula 2 elevado a n de forma recursiva 2^n = 2^(n/2)*2^(n/2) si n par y *2 si es impar 
	 * @param n		Valor del exponente
	 * @return		Valor de 2 elevado al exponente
	 */
	public long pow2Rec3 (int n) {
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		//doNothing();
		if(n == 0) {
			return 1;
		} else {
			if(n%2 == 0) {
				return pow2Rec3(n/2) * pow2Rec3(n/2);
			} else {
				return 2 * pow2Rec3(n/2) * pow2Rec3(n/2);
			}
		}
	} 

	/**
	 * Calcula 2 elevado a n de forma recursiva 2^n = como pow2Rec3 pero sin repetir llamada 
	 * @param n		Valor del exponente
	 * @return		Valor de 2 elevado al exponente
	 */
	public long pow2Rec4 (int n) {
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		//doNothing();
		if(n == 0) {
			return 1;
		} else {
			long result = pow2Rec3(n/2);
			if(n % 2 == 0) {
				return result * 2;
			} else {
				return result * result * 2;
			}
		}
	} 
	
//----------------------------	Métodos con 2 parámetros	--------------------------------------//
// Tener en cuenta que todos los métodos tienen el doNothing() comentado para probar las pruebas
// realizadas en el AlgorithmsTest ya que los tiempos ya salen medidos en los .txt
	
	/**
	 * Calcula a elevado a b de forma recursiva por potencias sucesivas
	 * @param n		Valor de la base
	 * @param m		Valor del exponente
	 * @return		Valor de la potencia
	 */
	public long potenciaRec(int n, int m) {
		if (n <= 0 || m < 0) {
			throw new IllegalArgumentException("No permitido alguno de los parámetros introducido"); 
		}
		doNothing();
		if(m == 0) {
			return 1;
		}
		if(m != 1) {
			return n*potenciaRec(n, m-1);
		} else {
			return n;
		}
	} 
	
	/**
	 * Calcula el resto de la división a/b de forma recursiva 
	 * @param n		Valor del dividendo
	 * @param m		Valor del divisor
	 * @return		Resto de la división 
	 */
	public long restoDivRec(int n, int m) {
		if (n < 0 || m <= 0) {
			throw new IllegalArgumentException("No permitido alguno de los parámetros introducido"); 
		}
		if(n >= m) {
			return restoDivRec(n-m, m);
		}
		return n;
	}
	
	/**
	 * Calcula la división entera a/b de forma recursiva 
	 * @param n		Valor del dividendo
	 * @param m		Valor del divisor
	 * @return		Cociente de la división
	 */
	public long divEntRec(int n, int m) {
		if (n < 0 || m <= 0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos"); 
		}
		return divEntRec2(n, m, 0);
	}
	
	private int divEntRec2(int n, int m, int contador) {
		if(n >= m) {
			return divEntRec2(n-m, m, contador+1);
		}
		return contador;
	}
	
//----------------------------	Métodos opcionales	--------------------------------------//
// Tener en cuenta que todos los métodos tienen el doNothing() comentado para probar las pruebas
// realizadas en el AlgorithmsTest ya que los tiempos ya salen medidos en los .txt
// No se realizó el test del método invertirStringRec, ya que este no depende del tamaño de n directamente (no hay diferencia del "aaaa" al "zzzz" o en el caso de otros métodos usados 1000 al 9999).
// El tiempo de respuesta depende de lo largo que sea el texto (además supondría cambiar de hacer el método que mide el tiempo y supondría mucho tiempo innecesario)
// Por tanto, cogeremos los valores obtenidos por el método invertirEnteroRec, que se basa en lo mismo que lo comentado anteriormente. 
// El método esSimetricaRec, tampoco realicé test porque el parámetro que debemos dar es diferente al que tenemos del método proporcionado por el profesorado.

	/**
	 * Invierte un entero invertirEnteroRec(1234)=4321 de forma recursiva 
	 * @param n		Valor del entero a invertir
	 * @return		Entero revertido
	 */
	public long invertirEnteroRec(int n) { 
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		return invertirEnteroRec2(n, 0);
	}

	private long invertirEnteroRec2(int n, int nuevo) {
		doNothing();
		if(n <= 0) {
			return nuevo;
		} 
		int x = n/10;
		int y = n%10;
		String z = String.valueOf(nuevo);
		return invertirEnteroRec2(x,Integer.parseInt(z+y));
	}
	
	/**
	 * Invierte un string de forma recursiva invertirStringRec("abc")="cba"
	 * @param n		Valor de la cadena de texto a invertir
	 * @return		Cadena de texto revertida
	 */
	public String invertirStringRec(String n) { // Invierte un string de forma recursiva invertirStringRec("abc")="cba"
		if (n == null) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		return invertirStringRec2(n, "");
	}
	
	private String invertirStringRec2(String n, String nuevo) {
		//doNothing();
		if(n.length() <= 0 || n.isBlank() || n.isEmpty()) {
			return nuevo;
		}
		String x = nuevo+n.substring(n.length()-1);
		String y = n.substring(0,n.length()-1);
		return invertirStringRec2(y,x);
	}
	
	/**
	 * Indica si es simétrica una matriz cuadrada de forma recursiva 
	 * @param m		Matriz para comprobar si es simétrica
	 * @return		True si la matriz es simetrica, False en caso contrario
	 */
	public boolean esSimetricaRec(int[][] m) {
		if(m == null) {
			throw new IllegalArgumentException("No permitidos parámetros nulos"); 
		}
		return esSimetricaRec2(m, 0, 0);
	}

	private boolean esSimetricaRec2(int[][] m, int i, int j) {
		doNothing();
		if(j == m[0].length) {
			return true;
		}
		if(m[i][j] == m[j][i]) {
			i+=1;
			if(i == m.length) {
				return esSimetricaRec2(m, 0, j+1);
			}
			return esSimetricaRec2(m,i, j);
		}
		return false;
	}
}
