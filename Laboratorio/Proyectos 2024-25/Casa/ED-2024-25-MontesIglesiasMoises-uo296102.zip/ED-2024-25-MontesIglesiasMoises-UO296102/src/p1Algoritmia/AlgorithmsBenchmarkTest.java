package p1Algoritmia;

import org.junit.jupiter.api.Test;

/**
 * @version 2023-24
 */

class AlgorithmsBenchmarkTest {
	// Tener en cuenta que todos los métodos tienen el doNothing() comentado para probar las pruebas
	// realizadas en el AlgorithmsTest ya que los tiempos ya salen medidos en los .txt
	/**
	 * Test para el calculo del tiempo de ejecucion del algoritmo implementado en el metodo "miPrueba" de la clase "Algorithms"
	 */
	@Test
	
	void testLinearBenchmark() {
		//AlgorithmsBenchmark ab = new AlgorithmsBenchmark();
		
		//ab.testFinal("lineal.txt", 0, 1000, 5, "p1Algoritmia.Algorithms", "miPrueba");
		
		//ab.testFinal("testLineal.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "linear");
		//ab.testFinal("testCuadratic.txt", 0, 20, 5, "p1Algoritmia.Algorithms", "cuadratic");
		//ab.testFinal("testCubic.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "cubic");
		//ab.testFinal("testLogarithmic.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "logarithmic");
		//ab.testFinal("testFactorial.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "factorial");
		//ab.testFinal("testFibonacci.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "fibonacci");
		
		//ab.testFinal("testPow2Rec1.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec1");
		//ab.testFinal("testPow2Rec2.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec2");
		//ab.testFinal("testPow2Rec3.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec3");
		//ab.testFinal("testPow2Rec4.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec4");
		//ab.testFinal("testPow2Iter.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "pow2Iter");
		
		//Solo funciona el primer método debido a que el parámetro de los otros es diferente al resto.
		//ab.testFinal("testInvertirEnteroRec.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "invertirEnteroRec");
		//ab.testFinal("testEsSimetricaRec.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "esSimetricaRec");
		//ab.testFinal("testInvertirStringRec.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "invertirStringRec");
		
		//Métodos opcionales ---------> No funciona la creación de los ficheros, pero los métodos están creados y comprobados
		//ab.testFinal("testInvertirEnteroRec.txt", 0, 100, 5, "p1Algoritmia.Algorithms", "invertirEnteroRec");
		//ab.testFinal("testRestoDivRec.txt", 0, 100, 5, "p1Algoritmia.Algorithms", "restoDivRec");
		//ab.testFinal("testDivEntRec.txt", 0, 100, 5, "p1Algoritmia.Algorithms", "divEntRec");
	}
}
