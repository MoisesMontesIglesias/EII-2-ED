package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class linear_quadratic_cubic_logarithmic {

	/**
	 * Test referentes al m�todo lineal
	 */
	@Test
	void test0() {
		try {
			Algoritmos.lineal(-3);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
	}
	
	/**
	 * Test referentes al m�todo quadratic
	 */
	@Test
	void test1() {
		try {
			Algoritmos.quadratic(-3);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
	}
	
	/**
	 * Test referentes al m�todo cubic
	 */
	@Test
	void test2() {
		try {
			Algoritmos.cubic(-3);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
	}
	
	/**
	 * Test referentes al m�todo logarithmic
	 */
	@Test
	void test3() {
		try {
			Algoritmos.logarithmic(-3);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
	}

}
