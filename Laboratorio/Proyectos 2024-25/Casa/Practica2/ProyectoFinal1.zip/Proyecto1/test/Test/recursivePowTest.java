package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class recursivePowTest {

	
	/**
	 * Test referentes al m�todo recursivePow0
	 */
	@Test
	void test0() {
		try {
			assertEquals(Algoritmos.recursivePow0(-3),9);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
		assertEquals(Algoritmos.recursivePow0(5),32);
		assertEquals(Algoritmos.recursivePow0(10),1024);
		assertEquals(Algoritmos.recursivePow0(1), 2);
		assertEquals(Algoritmos.recursivePow0(0), 1);
	}
	
	/**
	 * Test referentes al m�todo recursivePow1
	 */
	@Test
	void test1() {
		try {
			assertEquals(Algoritmos.recursivePow1(-3),9);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
		assertEquals(Algoritmos.recursivePow1(5),32);
		assertEquals(Algoritmos.recursivePow1(10),1024);
		assertEquals(Algoritmos.recursivePow1(1), 2);
		assertEquals(Algoritmos.recursivePow1(0), 1);
	}
	
	/**
	 * Test referentes al m�todo recursivePow2
	 */
	@Test
	void test2() {
		try {
			assertEquals(Algoritmos.recursivePow2(-3),9);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
		assertEquals(Algoritmos.recursivePow2(5),32);
		assertEquals(Algoritmos.recursivePow2(10),1024);
		assertEquals(Algoritmos.recursivePow2(1), 2);
		assertEquals(Algoritmos.recursivePow2(0), 1);
	}
	
	/**
	 * Test referentes al m�todo recursivePow3
	 */
	@Test
	void test3() {
		try {
			assertEquals(Algoritmos.recursivePow3(-3),9);
		} catch(RuntimeException e) {
			assertEquals("Introduce un n�mero positivo", e.getMessage());
		}
		assertEquals(Algoritmos.recursivePow3(5),32);
		assertEquals(Algoritmos.recursivePow3(10),1024);
		assertEquals(Algoritmos.recursivePow3(1), 2);
		assertEquals(Algoritmos.recursivePow3(0), 1);
	}
}
