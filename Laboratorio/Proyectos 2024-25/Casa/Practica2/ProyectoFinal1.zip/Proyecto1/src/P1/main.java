package P1;

import java.io.IOException;

public class main {
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		//System.out.println(TestBench.testAlgorithm("P1.Algoritmos", "iterativoFactorial", 6));
		
		//TestBench.test("lineal.csv",5, 1, 10, "P1.Algoritmos", "lineal");
		//TestBench.test("quadratic.csv",5, 1, 10, "P1.Algoritmos", "quadratic");
		//TestBench.test("cubic.csv",5, 1, 10, "P1.Algoritmos", "cubic");
		//TestBench.test("logarithmic.csv",5, 1, 10, "P1.Algoritmos", "logarithmic");
		//TestBench.test("recursivePow0.csv",5, 1, 10, "P1.Algoritmos", "recursivePow0");
		//TestBench.test("recursivePow1.csv",5, 1, 10, "P1.Algoritmos", "recursivePow1");
		//TestBench.test("recursivePow2.csv",5, 1, 10, "P1.Algoritmos", "recursivePow2");
		//TestBench.test("recursivePow3.csv",5, 1, 10, "P1.Algoritmos", "recursivePow3");
		
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "quadratic");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "cubic");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "logarithmic");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "logarithmic");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "recursivePow");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "recursivePow1");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "recursivePow2");
//		TestBench.test(5, 1, 5, "P1.Algoritmos", "recursivePow3");
	}
}
