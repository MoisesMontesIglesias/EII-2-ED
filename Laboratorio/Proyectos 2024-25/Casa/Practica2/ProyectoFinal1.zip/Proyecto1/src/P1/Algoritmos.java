package P1;

public class Algoritmos {
	
	private static int a;
	private static final long SLEEP_TIME = 250;
	
	public static int doNothing() {
		try {
			Thread.sleep(SLEEP_TIME);
			return 0;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
	
	
	public static int iterativeFactorial(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		a = 1;
		for (int i = 2; i < n+1; i++) {
			a *= i;
		}

		return a;
	}
	
	public static int iterativeFibonacci(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if(n == 0) {
			return 0;
		}	
		int fibo1 = 1;
		int fibo2 = 1;
		for (int i = 2; i < n; i++) {
			fibo2 = fibo1 + fibo2;
			fibo1 = fibo2 - fibo1;
		}
		return fibo2;
	}
	
	public static int iterativePow(int base, int exponente) {
		if (base < 0 || exponente < 0) {
			throw new IllegalArgumentException("Introduce ambos n�meros positivos");
		}
		if (exponente == 0) {
			return 1;
		}	
		return (int) Math.pow(base, exponente);
	}
	
	public static int recursiveFactorial(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if(n == 0) {
			return 1;
		} else {
			return n*recursiveFactorial(n-1);
		}
	}
	
	public static int recursivePow(int base, int exponente) {
		if (exponente < 0) {
			throw new IllegalArgumentException("Introduce ambos n�meros positivos");
		}
		if (exponente == 0) {
			doNothing();
			return 1;
		}else {
			doNothing();
			return base * recursivePow(base, exponente-1);
		}
		
	}
	
	public static int recursiveFibonacci(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if (n == 0) {
			return 0;
		} else if(n == 1) {
			return 1;
		}
		return recursiveFibonacci(n-1) + recursiveFibonacci(n-2);
	}
	
	public static void lineal(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		for (int i = 0; i < n; i++) {
			//doNothing();
		}
	}
	
	public static void quadratic(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				//doNothing();
			}
		}
	}
	
	public static void cubic(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				for (int k = 0; k < n; k++) {
					//doNothing();
				}
			}
		}
	}
	
	public static void logarithmic(int n) {
		if(n < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		while (n>1) {
			//doNothing();
			n = n/2;
		}
	}
	
	public static int recursivePow0(int exponente) {
		doNothing();
		if (exponente < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if(exponente == 0) {
			return 1;
		}
		return 2*recursivePow0(exponente-1);
	}
	
	public static int recursivePow1(int exponente) {
		doNothing();
		if (exponente < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if (exponente == 0) {
			return 1;
		}else {
			return (recursivePow1(exponente-1) + recursivePow1 (exponente-1));
		}
	}
	
	public static int recursivePow2(int exponente) {
		doNothing();
		if (exponente < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if (exponente == 0) {
			return 1;
		}else {
			if (exponente % 2 == 0) {
				return (recursivePow2(exponente/2) * recursivePow2 (exponente/2));
			}else {
				return (recursivePow2(exponente/2) * recursivePow2 (exponente/2) * 2);
			}	
		}
	}
	
	public static int recursivePow3(int exponente) {
		doNothing();
		if (exponente < 0) {
			throw new IllegalArgumentException("Introduce un n�mero positivo");
		}
		if (exponente == 0) {
			return 1;
		}else {
			long result = recursivePow3 (exponente/2);
			if (exponente % 2 == 0) {
				return (int) (result * result);
			}else { 
				return (int) (result * result * 2);
			}
		}
	}
}
