package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class potenciaTest {

	
	@Test
	public void test1() {
		assertEquals(Algoritmos.iterativePow(3,3),27);
		assertEquals(Algoritmos.recursivePow(3,3),27);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativePow(0,0),1);
		assertEquals(Algoritmos.recursivePow(0,0),1);
	}
	
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativePow(6,6),46656);
		assertEquals(Algoritmos.recursivePow(6,6),46656);
	}
}
