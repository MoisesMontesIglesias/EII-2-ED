package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class factorialTest {

	@Test
	public void test() {
		assertEquals(Algoritmos.iterativeFactorial(3),6);
		assertEquals(Algoritmos.recursiveFactorial(3),6);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativeFactorial(0),1);
		assertEquals(Algoritmos.recursiveFactorial(0),1);
	}
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativeFactorial(10),3628800);
		assertEquals(Algoritmos.recursiveFactorial(10),3628800);
	}

}
