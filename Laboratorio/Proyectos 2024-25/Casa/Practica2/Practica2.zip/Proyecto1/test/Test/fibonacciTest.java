package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class fibonacciTest {

	@Test
	public void test1() {
		assertEquals(Algoritmos.iterativeFibonacci(3),2);
		assertEquals(Algoritmos.recursiveFibonacci(3),2);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativeFibonacci(0),0);
		assertEquals(Algoritmos.recursiveFibonacci(0),0);
	}
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativeFibonacci(10),55);
		assertEquals(Algoritmos.recursiveFibonacci(10),55);
	}

}
