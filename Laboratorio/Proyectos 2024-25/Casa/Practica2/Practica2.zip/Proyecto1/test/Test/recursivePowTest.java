package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class recursivePowTest {

	/**
	 * Test referentes a la potencia recursiva
	 */
	@Test
	void test() {
		assertEquals(Algoritmos.recursivePow1(5),32);
		assertEquals(Algoritmos.recursivePow1(10),1024);
		assertEquals(Algoritmos.recursivePow1(1), 2);
		assertEquals(Algoritmos.recursivePow1(0), 1);
	}
	
	/**
	 * Test referentes a la potencia recursiva
	 */
	@Test
	void test2() {
		assertEquals(Algoritmos.recursivePow2(5),32);
		assertEquals(Algoritmos.recursivePow2(10),1024);
		assertEquals(Algoritmos.recursivePow2(1), 2);
		assertEquals(Algoritmos.recursivePow2(0), 1);
	}
}
