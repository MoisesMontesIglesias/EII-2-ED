package P3.BST;

	
	/**
	* @author Prodesores ED (Español)
	* @version 2023-24 distribuible
	*/
	public class BSTree <T extends Comparable<T>>{
	
	/**
	 * El nodo raiz del arbol. DEBE SER PRIVADO PARA NO PERDER EL ARBOL
	 */
	private BSTNode<T> raiz;
	
	/**
	 * Constructor por defecto para la clase BSTree
	 */
	public BSTree() {
		raiz = null;
	}
	
	/**
	 * getter del nodo raiz del arbol
	 */
	protected BSTNode<T> getRoot() {
		return raiz;
	}
	
	/**
	 * setter del nodo raiz del arbol
	 */
	protected void setRoot(BSTNode<T> nodo) {
		raiz = nodo;
	}
	
	
	/**
	 * Se le pasa el objeto comparable que hay que insertar
	 * devuelve true si lo inserta
	 * Si ya existe, no lo inserta y devuelve false (implementado mas tarde). 
	 * Si recibe un nodo nulo, no lo inserta y lanza una NullPointerException
	 */
	public boolean addNode(T node) {
		if(node == null || node.equals(null)) {
			throw new NullPointerException();
		}
		if(searchNode(node) != null) {
			return false;
		}
		if(raiz == null) {
			raiz = new BSTNode<T> (node);
			return true;
		}else {
			addNodeR(raiz,node);
			return true;
		}
	}
	
	
	private void addNodeR(BSTNode<T> actual, T node) {
		if(actual.equals(null)) {
			actual.setInfo(node);
		}
		// El problema es que siempre se escribe el mismo numero porq pasa por el else
		if(node.equals(actual.getInfo())) {
			throw new RuntimeException("AAAA");
		} else if(node.compareTo(actual.getInfo()) < 0) {
			addNodeR(actual.getLeft(), node);
			//actual.setLeft(actual.getLeft());
		} else if(node.compareTo(actual.getInfo()) > 0) {
			addNodeR(actual.getRight(), node);
			//actual.setRight(actual.getRight()); 
		}
	}

	/**
	* Se le pasa un objeto comparable que se busca
	* Devuelve el objeto encontrado que cumple que es "equals" con el
	* buscado, null si no lo encuentra por cualquier motivo
	*/
	public BSTNode<T> searchNode(T node) {;
		if(node == null) {
			return null;
		}
		if(raiz == null) {
			return null;
		}
		return recursiveSearch(node,getRoot());
	}
	
	/**
	 * Busqueda recursiva
	 * @param node
	 * @param raiz
	 * @return BSTNode
	 */
	private BSTNode<T> recursiveSearch(T node, BSTNode<T> actual) {
		if(node == null || actual == null) {
			return null;
		}
		if(actual.getInfo().equals(node)) {
			return actual;
		}
		if(actual.getInfo().compareTo(node) > 0) {
			//Si es menor por la izquierda
			return recursiveSearch(node, actual.getLeft());
		} else {
			//Si es mayor por la derecha
			return recursiveSearch(node, actual.getRight());
		}
	}

	/**
	* Genera un String con el recorrido en pre-orden (izquierda-derecha)
	* (toString de los nodos separados por tabuladores)
	*/
	public String preOrder() {
		String path = "";
		return recursivePreOrder(raiz, path);
	}
	
	
	private String recursivePreOrder(BSTNode<T> actual, String path) {
		if (actual==null) {
			return "";
		}
		path = actual.toString() + "\t" + recursivePreOrder(actual.getLeft(), path) 
		+ recursivePreOrder(actual.getRight(), path);
		return path;
	}

	/**
	* Genera un String con el recorrido en post-orden (izquierda-derecha)
	* (toString de los nodos separados por tabuladores)
	*/
	public String postOrder() {
		String path = "";
		return recursivePostOrder(raiz, path);
	}
	
	
	private String recursivePostOrder(BSTNode<T> actual, String path) {
		if (raiz==null) {
			return "";
		}		
		path = recursivePostOrder(actual.getLeft(), path)
		+ recursivePostOrder(actual.getRight(), path) + actual.toString() + "\t";
		return path;
	}

	/**
	* Genera un String con el recorrido en in-orden (izquierda-derecha)
	* (toString de los nodos separados por tabuladores)
	*/
	public String inOrder() {
		String path = "";
		return recursiveInOrder(raiz, path);
	}
	
	
	private String recursiveInOrder(BSTNode<T> actual, String path) {
		if (raiz==null) {
			return "";
		}
		path = recursiveInOrder(actual.getLeft(), path) + actual.toString() + "\t" 
		+ recursiveInOrder(actual.getRight(), path);
		return path;
	}

	/**
	* Se le pasa el objeto que se quiere borrar que coincida con equals
	* Si recibe un nodo nulo, lanza una NullPointerException
	* Devuelve true si lo ha borrado, false caso contrario
	*/
	public boolean removeNode (T node){
		return false;
	}
	
	
	
	public String toString() {
		return tumbarArbol(raiz, 0);
	}
	
	
	
	/**
	* Genera un String con el arbol "tumbado" (la raiz a la izquierda y las ramas hacia la derecha)
	* Es un recorrido InOrden-Derecha-Izquierda, tabulando para mostrar los distintos niveles
	* Utiliza el toString de la informacion almacenada
	*
	* @param p La raiz del arbol a mostrar tumbado
	* @param esp El espaciado en numero de tabulaciones para indicar la profundidad
	* @return El String generado
	*/
	protected String tumbarArbol(BSTNode<T> p, int esp) {
	StringBuilder cadena = new StringBuilder();
	
		if (p != null) {
			cadena.append(tumbarArbol(p.getRight(), esp + 1));
			for (int i = 0; i < esp; i++)
				cadena.append("\t");
			cadena.append(p + "\n");
			cadena.append(tumbarArbol(p.getLeft(), esp + 1));
		}
		return cadena.toString();
	}


}