package p1Algoritmia;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AlgorithmsTest {
	
	Algorithms alg = new Algorithms();
	
	@Test
	void testFactorial() {
		for (int i = 0; i < 30; i++) {
			System.out.println(alg.factorial(i));
		}
		assertEquals(120, alg.factorial(5));
		assertEquals(1, alg.factorial(0));
		assertThrows(IllegalArgumentException.class, () -> {alg.factorial(-1);}); 
	}
	
	@Test
	void testFibonacci() {
		for (int i = 0; i < 10; i++) {
			System.out.println(alg.fibonacci(i));
		}
		assertEquals(5, alg.fibonacci(5));
		assertEquals(0, alg.fibonacci(0));
		assertEquals(34, alg.fibonacci(9));
		assertThrows(IllegalArgumentException.class, () -> {alg.fibonacci(-1);}); 
	}

	@Test
	void testPowRec1() {
		for (int i = 0; i < 10; i++) {
			System.out.println(alg.pow2Rec1(i));
		}
		assertEquals(1, alg.pow2Rec1(0));
		assertEquals(2, alg.pow2Rec1(1));
		assertEquals(4, alg.pow2Rec1(2));
		assertEquals(8, alg.pow2Rec1(3));
		assertEquals(Math.pow(2, 10), alg.pow2Rec1(10));
		assertThrows(IllegalArgumentException.class, () -> {alg.pow2Rec1(-1);}); 
	}
	
	@Test
	void testPotenciaRec() {
		for (int i = 0; i < 10; i++) {
			System.out.println(alg.pow2Rec1(i));
		}
		assertEquals(1, alg.pow2Rec1(0));
		assertEquals(2, alg.pow2Rec1(1));
		assertEquals(4, alg.pow2Rec1(2));
		assertEquals(8, alg.pow2Rec1(3));
		assertEquals(Math.pow(2, 10), alg.pow2Rec1(10));
		assertThrows(IllegalArgumentException.class, () -> {alg.pow2Rec1(-1);}); 
	}
	
	@Test
	void restoDivRec() {
		for (int i = 0; i < 10; i++) {
			System.out.println(alg.pow2Rec1(i));
		}
		assertEquals(1, alg.pow2Rec1(0));
		assertEquals(2, alg.pow2Rec1(1));
		assertEquals(4, alg.pow2Rec1(2));
		assertEquals(8, alg.pow2Rec1(3));
		assertEquals(Math.pow(2, 10), alg.pow2Rec1(10));
		assertThrows(IllegalArgumentException.class, () -> {alg.pow2Rec1(-1);}); 
	}
	
	@Test
	void divEntRec() {
		for (int i = 0; i < 10; i++) {
			System.out.println(alg.pow2Rec1(i));
		}
		assertEquals(1, alg.pow2Rec1(0));
		assertEquals(2, alg.pow2Rec1(1));
		assertEquals(4, alg.pow2Rec1(2));
		assertEquals(8, alg.pow2Rec1(3));
		assertEquals(Math.pow(2, 10), alg.pow2Rec1(10));
		assertThrows(IllegalArgumentException.class, () -> {alg.pow2Rec1(-1);}); 
	}

}
