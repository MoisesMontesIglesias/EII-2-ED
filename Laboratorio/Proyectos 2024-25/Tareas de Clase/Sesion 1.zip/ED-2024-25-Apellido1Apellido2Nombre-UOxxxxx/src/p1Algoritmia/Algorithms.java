package p1Algoritmia;

public class Algorithms {
	private static final long SLEEP_TIME = 1;

	public static void doNothing() {
		try {
			Thread.sleep(SLEEP_TIME);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Completad con los metodos que se os pidan...
	public long factorial (int n) { // Calcula el factorial de n>=0 de forma recursiva 
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		if(n!=0) {
			return n * factorial(n-1); //Si es el caso general
		}
		return 1; //Si es el caso base
	} 
	public int fibonacci (int n) { // Calcula el termino n-esimo teniendo en cuenta que el primer término se considera fib(0)=0; y fib(1)=1 
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		//Casos base
		if(n == 0) {
			return 0;
		} else if(n == 1) {
			return 1; 
		}
		return fibonacci(n-2) + fibonacci(n-1); //Si es el caso general

	} 
	// para pruebas de que produce una excepción... 
	//   assertThrows(IllegalArgumentException.class, () -> {al.factorial(-1);}); 

	public long pow2Rec1(int n) {  // calcula 2 elevado a n de forma recursiva 2^n = 2*2^(n-1) 
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		if(n == 0) {
			return 1;
		}
		if(n != 1) {
			return 2*pow2Rec1(n-1);
		} else {
			return 2;
		}
	} 
	
	public long potenciaRec(int n, int m) {  // calcula 2 elevado a n de forma recursiva 2^n = 2*2^(n-1) 
		if (n<0 && m < 0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n + " o " + m); 
		}
		if(m == 0) {
			return 1;
		}
		if(m != 1) {
			return n*potenciaRec(n, m-1);
		} else {
			return n;
		}
	} 
	
	public long restoDivRec(int n, int m) {
		if (n<0 && m < 0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n + " o " + m); 
		}
		if(n >= m) {
			return restoDivRec(n-m, m);
		}
		return n;
	}
	
	public long divEntRec(int n, int m) {
		if (n<0 && m < 0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n + " o " + m); 
		}
		if(n >= m) {
			return 1+divEntRec(n-m, m);
		}
		return 1;
	}
	
	public long invertirEnteroRec(int n) {
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		if(n < 10) {
			return n;
		}
		int x = n%10;
		String y = String.valueOf(n);
		return Integer.parseInt(x + y);
	}

	public String invertirStringRec(String n) {
		if (n == null) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		if(n.length() <= 1) {
			return n;
		}
		return n.length() + invertirStringRec(n.substring(-1));
	}
	
	public boolean esSimetricaRec(int[][] n, int[][] m) {
		if(n.length != m.length) {
			throw new IllegalArgumentException("Las dimensiones de las matrices no son iguales"); 
		}
		for (int i = 0; i < n.length; i++) {
			if(n[i][0] != m[i][0]) {
				return false;
			}
		}
	}
}
