package p2Grafos;


/**
 * @author Nestor
 * @version 2024-25 distribuible
 */
public class Graph<T> extends GraphAbstract<T> {
	
	/**
	 * 
	 * Se le pasa el numero maximo de nodos del grafo
	 */
	public Graph(int tam) {
		super(tam);
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
		
	}

	public Graph (int tam, T initialNodes[], boolean[][] initialEdges, double [][] initialWeights) {
		super(tam,initialNodes,initialEdges,initialWeights);
	}
	
    public Graph (int tam, T initialNodes[], boolean[][] initialEdges, double [][] initialWeights, double [][] initialAfloyd, int [][] initialPfloyd) { 
        super(tam, initialNodes,initialEdges,initialWeights,initialAfloyd,initialPfloyd);  
   } 


	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * Se le pasa el nodo y devuelve la posicion en el vector de nodos o -1 si no existe
	 */
	protected int getNode(T node) {
		if(node == null) {
			throw new NullPointerException("Element to insert is null");
		}
		for (int i = 0; i < numNodes; i++) {
			if(nodes[i].equals(node)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * 
	 * Inserta un nuevo nodo que se le pasa como parametro.
	 * Si ya existe, no lo inserta y devuelve false (implementado mas tarde). 
	 * Si recibe un nodo nulo, no lo inserta y lanza una NullPointerException
	 * Si no cabe, no lo inserta y lanza una FullStructureException.
	 * 
	 */
	public boolean addNode(T node) {
		if(node == null) {
			throw new NullPointerException("Element to insert is null.");
		}
		if(numNodes >= nodes.length) {
			throw new FullStructureException(node);
		}
		if(getNode(node) != -1) {
			return false;
		}
		nodes[numNodes] = node;
		for (int i = 0; i <= numNodes; i++) {
			edges[numNodes][i] = false;
			edges[i][numNodes] = false;
			weights[numNodes][i] = 0;
			weights[i][numNodes] = 0;
		}
		numNodes++;
		return true;
	}

	/**
	 * Si existe, borra el nodo deseado del vector de nodos asi como las aristas en
	 * las que forma parte y duvuelve true. 
	 * Si el nodo no existe devuelve false.
	 * Si recibe un nodo nulo, lanza una NullPointerException
	 * 
	 */
	public boolean removeNode(T node) {
		if(node == null) {
			throw new NullPointerException("Element to remove is null.");
		}
		if(!existsNode(node)) {
			return false;
		}
		int posNode = getNode(node);
		numNodes--;
		nodes[posNode] = nodes[numNodes];
		for (int i = 0; i < numNodes; i++) {
			edges[i][posNode] = edges[i][numNodes];
			edges[posNode][i] = edges[numNodes][i];
			weights[i][posNode] = weights[i][numNodes];
			weights[posNode][i] = weights[numNodes][i];
		}
		edges[posNode][posNode] = edges[numNodes][numNodes];
		weights[posNode][posNode] = weights[numNodes][numNodes];
		return true;
	}

	/**
	 * Si existe devuelve true
	 * Si no existe devuelve false
	 */
	public boolean existsNode(T node) {
		if(node == null || getNode(node) == -1) {
			return false;
		}
		return true;
	}

	/**
	 * Comprueba si existe una arista entre dos nodos que se pasan como parametro
	 * 
	 * Devuelve true si existe la arista entre los dos nodos que se le pasan
	 * Devuelve false si no existe la arista o no existen ambos nodos
	 */
	public boolean existsEdge(T source, T target) {
		if(existsNode(source) == false || existsNode(target) == false) {
			return false;
		}
		return edges[getNode(source)][getNode(target)];
	}

	/**
	 * Inserta una arista con el peso indicado (> 0) entre dos nodos, uno origen y
	 * otro destino. 
	 * Devuelve true si la inserta
	 * Devuelve falso si ya existe el arco (arista)
	 * Lanza una excepcion ElementNotPresentException si no existe el nodo origen o destino
	 * Lanza una IllegalArgumentException si el peso es invalido.
	 * 
	 */
	public boolean addEdge(T source, T target, double edgeWeight) {
		if(source == null || !existsNode(source)) {
			throw new ElementNotPresentException("Edge could not be loaded: source element " + source + " is not part of the graph.");
		}
		if(target == null || !existsNode(target)) {
			throw new ElementNotPresentException("Edge could not be loaded: target element " + target + " is not part of the graph.");
		}
		if(edgeWeight <= 0) {
			throw new IllegalArgumentException("Weight edge could not be less or equals to 0");
		}
		if(existsEdge(source, target)) {
			return false;
		}
		edges[getNode(source)][getNode(target)] = true;
		weights[getNode(source)][getNode(target)] = edgeWeight;
		return true;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos.
	 * Si la arista existe, se borra y devuelve true.
	 * Si los nodos source o target no existen, lanza una excepcion de tipo ElementNotPresentException
	 * Si tanto source como target existen, pero la arista a eliminar no, devuelve false.
	 * 
	 */
	public boolean removeEdge(T source, T target) {
		if(source == null) {
			throw new ElementNotPresentException("Edge could not be removed: " + source + " is not present in the current graph.");
		}
		if(target == null) {
			throw new ElementNotPresentException("Edge could not be removed: " + target + " is not present in the current graph.");
		}
		if(getNode(source) == -1 || getNode(target) == -1) {
			return false;
		}
		if(!existsEdge(source, target)) {
			return false;
		}
		edges[getNode(source)][getNode(target)] = false;
		weights[getNode(source)][getNode(target)] = -1;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos.
	 * Si los nodos source o target no existen, lanza una excepcion de tipo ElementNotPresentException
	 * Si tanto source como target existen, pero la arista a eliminar no, devuelve -1
	 * 
	 */

	public double getEdge(T source, T target) {
		if(source == null || !existsNode(source)) {
			throw new ElementNotPresentException("Edge weight could not be obtained: " + source + " is not present in the current graph.");
		}
		if(target == null || !existsNode(target)) {
			throw new ElementNotPresentException("Edge weight could not be obtained: " + target + " is not present in the current graph.");
		}
		if(existsEdge(source, target)) {
			return weights[getNode(source)][getNode(target)];
		}
		return -1;
	}

	/**
	 * Aplica el algoritmo de Floyd al grafo actual
	 * Devuelve true si lo aplica y false en caso contrario (no hay nodos en el grafo) 
	 */
	public boolean floyd() {
		if(numNodes == 0) {
			return false;
		}
		aFloyd = new double[numNodes][numNodes];
		pFloyd = new int[numNodes][numNodes];  
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				pFloyd[i][j] = -1;
				if(i == j) {
					aFloyd[i][j] = 0;
				} else if(existsEdge(nodes[i], nodes[j])){
					aFloyd[i][j] = weights[i][j];
				} else {
					aFloyd[i][j] = Double.POSITIVE_INFINITY;
				}
			}
		}
		for (int k = 0; k < numNodes; k++) {
			for (int i = 0; i < numNodes; i++) {
				for (int j = 0; j < numNodes; j++) {
					if(aFloyd[i][k] + aFloyd[k][j] < aFloyd[i][j]) {
						aFloyd[i][j] = aFloyd[i][k] + aFloyd[k][j];
						pFloyd[i][j] = k;
					}
				}
			}
		}
		return true;
	}

	/**
	 * Lanza el recorrido en profundidad de un grafo desde un nodo determinado, No
	 * necesariamente recorre todos los nodos. Al recorrer cada nodo hace un
	 * tratamiento del mismo que consiste en un concatenar el toString del nodo y un
	 * tabulador detras
	 * 
	 */
	public String recorridoProfundidad(T nodo) {
		return "";
	}

	/**
	 * Indica el camino entre los nodos que se le pasan como parametros de esta
	 * forma: donde cada nodo (Origen, Destino, IntermedioN,...) se refiere al
	 * toString del nodo correspondiente
	 * Origen<tabulador>(coste0)<tabulador>Intermedio1<tabulador>(coste1)<tabulador>IntermedioN<tabulador>(costeN)<tabulador>Destino<tabulador>
	 * Si no hay camino: Origen<tabulador>(Infinity)<tabulador>Destino<tabulador>
	 * Si Origen y Destino coinciden: Origen<tabulador> 
	 * Si no existen los 2 nodos devuelve una cadena vacia
	 * 
	 */
	public String path(T origen, T destino) {
		if(!existsNode(origen)) {
			throw new NullPointerException();
		}
		if(!existsNode(destino)) {
			throw new NullPointerException();
		}
		int k = pFloyd[getNode(origen)][getNode(destino)];
		String cadena = "";
		if(k >= 0) {
			cadena += path(origen, destino) + "-";
		}
		return cadena;
	}

	/**
	 * Algoritmo de Dijkstra para encontrar el camino de coste minimo desde
	 * nodoOrigen hasta el resto de nodos
	 * Se le pasa el nodo origen como parametro
	 * Devuelve una DijkstraDataClass con los vectores D y P correspondientes si se aplica o null si no se puede aplicar
	 * 
	 */
	public DijkstraDataClass dijkstra(T nodoOrigen) {
		DijkstraDataClass dj = new DijkstraDataClass(numNodes);
		if(nodoOrigen == null) {
			throw new NullPointerException("El nodo pasado por parámetro es null");
		}
		int posNode = getNode(nodoOrigen);
		if(posNode == -1){
			return null;
		}
		double[] vectorD = new double[numNodes];
		boolean[] nodesAlcanzados = new boolean[numNodes];
		int[] vectorP = new int[numNodes];
		for (int i = 0; i < numNodes; i++) {
			vectorP[i] = -1;
			if(i == posNode) {
				vectorD[i] = 0;
			} else if(edges[posNode][i]) {
				vectorD[i] = weights[posNode][i];
			} else {
				vectorD[i] = -1;
			}
		}
		dj.setdDijkstra(vectorD);
		dj.setpDijkstra(vectorP);
		int w = minCost(vectorD, nodesAlcanzados);
		while (w != -1) {
			nodesAlcanzados[w] = true;
			for (int i = 0; i < numNodes; i++) {
				if(edges[w][i] && !nodesAlcanzados[i] && vectorD[w] > vectorD[i] + weights[i][w]) {
					vectorD[w] = vectorD[i] + weights[i][w];
					vectorP[i] = w;
				}
			}
			w = minCost(vectorD, nodesAlcanzados);
		}
		return dj;
	}
	
	/**
	 * Busca el nodo con distancia minima en D al resto de nodos
	 * 
	 * Es una recomendacion pero no es imprescindible...
	 * 
	 * Se le pasa el vector d de dijkstra actual
	 * Un conjunto de visitados (conjunto S) como vector de booleanos 
	 * 	si se usa otro tipo de conjunto adaptarlo
	 * Se devuelve el indice del nodo buscado o -1 si el grafo es no conexo o no quedan
	 *         nodos sin visitar
	 */
	private int minCost(double[] vectorD, boolean[] nodesAlcanzados) {
		int pivote = -1;
		double menorValor = Double.POSITIVE_INFINITY;
		for (int i = 0; i < numNodes; i++) {
			if(vectorD[i] < menorValor && nodesAlcanzados[i] == false) {
				menorValor = vectorD[i];
				pivote = i;
			}
		}
		return pivote;
	}

	/**
	 * Devuelve el coste del camino de coste minimo entre origen y destino segun Floyd.
	 * Si los nodos source o target no existen, 
	 *        lanza una excepcion de tipo ElementNotPresentException
	 * Si no se ha aplicado Floyd, lo aplica. (OJO que este metodo SI lo invoca) 
	**/ 
	public double minCostPath(T origen, T destino) {
		if(getNode(origen) == -1) {
			throw new ElementNotPresentException(
					"Path could not be obtained: " + origen + " is not present in the current graph.");
		}
		if(getNode(destino) == -1) {
			throw new ElementNotPresentException(
					"Path could not be obtained: " + destino + " is not present in the current graph.");
		}
		floyd();
		return aFloyd[getNode(origen)][getNode(destino)];
	}

}
