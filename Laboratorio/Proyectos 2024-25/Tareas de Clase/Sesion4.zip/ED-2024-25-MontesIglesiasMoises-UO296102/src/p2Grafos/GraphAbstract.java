package p2Grafos;
/**
 * @author Nestor
 * @version 2024-25 Sesion 4
 */

import java.text.DecimalFormat;

public abstract class GraphAbstract<T> {
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int numNodes; // numero de elementos en un momento dado


	/**
	 * 
	 * @param tam
	 *            Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphAbstract(int tam) {
		nodes = (T[]) new Object[tam];
		numNodes = 0;
	}

	public GraphAbstract(int tam, T initialNodes[], boolean[][] initialEdges, double [][] initialWeights){
		// Llama al constructor original
		this(tam); 
		
		// Crea tambien las matrices de aristas y pesos...
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];

		// Pero modifica los atributos con los parametros para hacer pruebas...
		numNodes = initialNodes.length;
		
		for (int i=0;i<numNodes;i++) {
			nodes[i]=initialNodes[i];
			for (int j=0;j<numNodes;j++){
				edges[i][j]=initialEdges[i][j];
				weights[i][j]=initialWeights[i][j];
			}
		}
	}

	/**
	 * @return Devuelve un String con la informacion del grafo (incluyendo matrices de Floyd)
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		String cadena = "";

		cadena += "NODES\n";
		for (int i = 0; i < numNodes; i++) {
			cadena += nodes[i].toString() + "\t";
		}
		cadena += "\n\nEDGES\n";
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (edges[i][j])
					cadena += "T\t";
				else
					cadena += "F\t";
			}
			cadena += "\n";
		}
		cadena += "\nWEIGHTS\n";
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {

				cadena += (edges[i][j]?df.format(weights[i][j]):"-") + "\t";
			}
			cadena += "\n";
		}

		return cadena;
	}

}
