package p2Grafos;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class GraphTest {
	
	Graph<Integer> gr = new Graph<Integer>(50);
	
	@Test
	void getNodeTest() {
		assertThrows(NullPointerException.class, () -> {gr.getNode(null);});
		gr.addNode(3);
		assertEquals(gr.getNode(3), 0);
		gr.addNode(5);
		gr.addNode(7);
		assertEquals(gr.getNode(7), 2);
		assertEquals(gr.getNode(20), -1);
	}
	
	@Test
	void addNodeTest() {
		assertThrows(NullPointerException.class, () -> {gr.addNode(null);}); 
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(5));
		assertFalse(gr.addNode(3));
		gr.numNodes = 51;
		assertThrows(FullStructureException.class, () -> {gr.addNode(17);}); 
	}
	
	@Test
	void removeNodeTest() {
		assertThrows(NullPointerException.class, () -> {gr.removeNode(null);}); 
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(5));
		assertTrue(gr.addNode(2));
		assertTrue(gr.addNode(1));
		assertTrue(gr.addNode(9));
		assertFalse(gr.addNode(3));
		gr.addEdge(3, 5, 2);
		System.out.println(gr.toString());
		assertTrue(gr.removeNode(5));
		System.out.println(gr.toString());
		assertFalse(gr.removeNode(8));
	}
	
	@Test
	void addEdge() {
		gr.addNode(1);
		gr.addNode(2);
		assertTrue(gr.addEdge(1, 2, 4));
		assertFalse(gr.addEdge(1, 2, 7));
		assertThrows(ElementNotPresentException.class, () -> {gr.addEdge(null, 2, 3);});
		assertThrows(ElementNotPresentException.class, () -> {gr.addEdge(1, null, 7);});
		assertThrows(IllegalArgumentException.class, () -> {gr.addEdge(1, 2, 0);});
		assertThrows(IllegalArgumentException.class, () -> {gr.addEdge(1, 2, -5);});
		
	}
	
	@Test
	void removeEdge() {
		gr.addNode(1);
		gr.addNode(2);
		gr.addEdge(1, 2, 4);
		assertTrue(gr.removeEdge(1, 2));
	}
}
