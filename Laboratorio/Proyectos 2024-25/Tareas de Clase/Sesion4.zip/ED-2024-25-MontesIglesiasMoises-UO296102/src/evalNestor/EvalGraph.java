//  NO MODIFICAR NOMBRE DE ESTE PAQUETE, crear (si no existe ya) un paquete nuevo en vuestro proyecto que se llame asi: "evalNestor"
//  y meted en el esta clase
package evalNestor;
/**
 * @author Nestor
 * @version 2024-25 Sesion 4
 */

import p2Grafos.Graph;

public class EvalGraph<T> extends Graph<T> {
	
	Alumno alum=new Alumno();
	
	public EvalGraph(int tam) {
		// Llama al constructor original
		super(tam);
	}
	
//	public EvalGraph(int tam,T initialNodes[], boolean[][] initialEdges, double [][] initialWeights){
//		super(tam,initialNodes,initialEdges,initialWeights); 
//	}
	
	public String getNombreFicheroAlumno(){
		return alum.getNombreFicheroAlumno();
	}

}

/*  

//  debe estar incluido este constructor en la clase Graph, copiadlo...
public Graph (int tam, T initialNodes[], boolean[][] initialEdges, double [][] initialWeights) {
		super(tam,initialNodes,initialEdges,initialWeights);
	}

*/
