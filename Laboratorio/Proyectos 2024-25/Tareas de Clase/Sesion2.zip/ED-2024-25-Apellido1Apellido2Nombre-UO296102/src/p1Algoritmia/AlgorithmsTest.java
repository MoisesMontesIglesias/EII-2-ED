package p1Algoritmia;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AlgorithmsTest {
	
	Algorithms alg = new Algorithms();
	
	@Test
	void testFactorial() {
		for (int i = 0; i < 30; i++) {
			//System.out.println(alg.factorial(i));
		}
		assertEquals(120, alg.factorial(5));
		assertEquals(1, alg.factorial(0));
		assertThrows(IllegalArgumentException.class, () -> {alg.factorial(-1);}); 
	}
	
	@Test
	void testFibonacci() {
		for (int i = 0; i < 10; i++) {
			//System.out.println(alg.fibonacci(i));
		}
		assertEquals(5, alg.fibonacci(5));
		assertEquals(0, alg.fibonacci(0));
		assertEquals(34, alg.fibonacci(9));
		assertThrows(IllegalArgumentException.class, () -> {alg.fibonacci(-1);}); 
	}

	@Test
	void testPowRec1() {
		for (int i = 0; i < 10; i++) {
			//System.out.println(alg.pow2Rec1(i));
		}
		assertEquals(1, alg.pow2Rec1(0));
		assertEquals(2, alg.pow2Rec1(1));
		assertEquals(4, alg.pow2Rec1(2));
		assertEquals(8, alg.pow2Rec1(3));
		assertEquals(Math.pow(2, 10), alg.pow2Rec1(10));
		assertThrows(IllegalArgumentException.class, () -> {alg.pow2Rec1(-1);}); 
	}
	
	@Test
	void testPotenciaRec() {
		for (int i = 0; i < 10; i++) {
			//System.out.println(alg.pow2Rec1(i));
		}
		assertEquals(4, alg.potenciaRec(2,2));
		assertEquals(8, alg.potenciaRec(2,3));
		assertEquals(16, alg.potenciaRec(2,4));
		assertEquals(1, alg.potenciaRec(2,0));
		assertThrows(IllegalArgumentException.class, () -> {alg.potenciaRec(-1, 2);}); 
		assertThrows(IllegalArgumentException.class, () -> {alg.potenciaRec(1000, -30);}); 
	}
	
	@Test
	void testRestoDivRec() {
		assertEquals(1, alg.restoDivRec(15,2));
		assertEquals(0, alg.restoDivRec(15,3));
		assertEquals(3, alg.restoDivRec(15,4));
		assertEquals(0, alg.restoDivRec(15,5));
		assertThrows(IllegalArgumentException.class, () -> {alg.restoDivRec(-1, 2);}); 
		assertThrows(IllegalArgumentException.class, () -> {alg.restoDivRec(1000, -30);}); 
		assertThrows(IllegalArgumentException.class, () -> {alg.restoDivRec(-2,8);}); 
	}
	
	@Test
	void testDivEntRec() {
		assertEquals(7, alg.divEntRec(15,2));
		assertEquals(5, alg.divEntRec(15,3));
		assertEquals(3, alg.divEntRec(15,4));
		assertEquals(1, alg.divEntRec(15,11));
		assertThrows(IllegalArgumentException.class, () -> {alg.divEntRec(-1, 2);}); 
		assertThrows(IllegalArgumentException.class, () -> {alg.divEntRec(1000, -30);}); 
	}
	
	@Test
	void testInvertirEnteroRec() {
		assertEquals(1001, alg.invertirEnteroRec(1001));
		assertEquals(1234, alg.invertirEnteroRec(4321));
		assertEquals(4331, alg.invertirEnteroRec(1334));
		assertEquals(4441, alg.invertirEnteroRec(1444));
		assertThrows(IllegalArgumentException.class, () -> {alg.invertirEnteroRec(-1001);;}); 
		assertThrows(IllegalArgumentException.class, () -> {alg.invertirEnteroRec(-34);;}); 
	}
	
	@Test
	void testInvertirStringRec() {
		assertEquals("aloH", alg.invertirStringRec("Hola"));
		assertEquals("uoiea", alg.invertirStringRec("aeiou"));
		assertEquals("uoiea", alg.invertirStringRec("aeiou"));
		assertEquals("fEdCbA", alg.invertirStringRec("AbCdEf"));
		assertThrows(IllegalArgumentException.class, () -> {alg.invertirStringRec(null);}); 
	}
	
	
	@Test
	void testEsSimetricaRec() {
		int[][] m = new int[][]{{1,2,3},{2,3,1},{3,1,2}};
		int[][] n = new int[][]{{1,2,3},{4,5,6},{7,8,9}};
		int[][] o = new int[][]{{1,2,3},{4,5,6}};
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[0].length; j++) {
				//System.out.println(m[i][j]);
			}
		}
		assertTrue(alg.esSimetricaRec(m));
		assertFalse(alg.esSimetricaRec(n));
		assertFalse(alg.esSimetricaRec(o));
	}
	
	@Test
	void testPow2Rec2() {
		assertEquals(32, alg.pow2Rec2(5));
		assertEquals(128, alg.pow2Rec2(7));
		assertEquals(512, alg.pow2Rec2(9));
		assertEquals(2048, alg.pow2Rec2(11));
		assertThrows(IllegalArgumentException.class, () -> {alg.pow2Rec2(-1);}); 
	}

}
