package p1Algoritmia;

import org.junit.jupiter.api.Test;

/**
 * @version 2023-24
 */

class AlgorithmsBenchmarkTest {

	/**
	 * Test para el calculo del tiempo de ejecucion del algoritmo implementado en el metodo "miPrueba" de la clase "Algorithms"
	 */
	@Test
	void testLinearBenchmark() {
		AlgorithmsBenchmark ab = new AlgorithmsBenchmark();
		//ab.testFinal("lineal.txt", 0, 1000, 5, "p1Algoritmia.Algorithms", "miPrueba");
		//**ab.testFinal("testLineal.txt", 0, 50, 5, "p1Algoritmia.Algorithms", "linear");
		//ab.testFinal("testCuadratic.txt", 0, 20, 5, "p1Algoritmia.Algorithms", "cuadratic");
		//**ab.testFinal("testCubic.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "cubic");
		//**ab.testFinal("testLogarithmic.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "logarithmic");
		//ab.testFinal("testPow2Rec1.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec1");
		//ab.testFinal("testPow2Rec2.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec2");
		//**ab.testFinal("testPow2Rec3.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec3");
		//**ab.testFinal("testPow2Rec4.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "pow2Rec4");
		//**ab.testFinal("testPow2Iter.txt", 0, 50, 0, "p1Algoritmia.Algorithms", "pow2Iter");
		//ab.testFinal("testFactorial.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "factorial");
		//ab.testFinal("testFibonacci.txt", 0, 10, 5, "p1Algoritmia.Algorithms", "fibonacci");
	}
}
