package p2Grafos;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class GraphTest {
	
	Graph<Integer> gr = new Graph<Integer>(50);
	
	@Test
	void getNodeTest() {
		assertThrows(NullPointerException.class, () -> {gr.getNode(null);});
		gr.addNode(3);
		assertEquals(gr.getNode(3), 0);
		gr.addNode(5);
		gr.addNode(7);
		assertEquals(gr.getNode(7), 2);
		assertEquals(gr.getNode(20), -1);
	}
	
	@Test
	void addNodeTest() {
		assertThrows(NullPointerException.class, () -> {gr.addNode(null);}); 
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(5));
		assertFalse(gr.addNode(3));
		gr.numNodes = 51;
		assertThrows(FullStructureException.class, () -> {gr.addNode(17);}); 
	}
	
	@Test
	void removeNodeTest() {
		assertThrows(NullPointerException.class, () -> {gr.removeNode(null);}); 
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(5));
		assertTrue(gr.addNode(2));
		assertTrue(gr.addNode(1));
		assertTrue(gr.addNode(9));
		assertFalse(gr.addNode(3));
		gr.addEdge(3, 5, 2);
		assertTrue(gr.removeNode(5));
		assertFalse(gr.removeNode(8));
	}
	
	@Test
	void addEdge() {
		gr.addNode(1);
		gr.addNode(2);
		assertTrue(gr.addEdge(1, 2, 4));
		assertFalse(gr.addEdge(1, 2, 7));
		assertThrows(ElementNotPresentException.class, () -> {gr.addEdge(null, 2, 3);});
		assertThrows(ElementNotPresentException.class, () -> {gr.addEdge(1, null, 7);});
		assertThrows(IllegalArgumentException.class, () -> {gr.addEdge(1, 2, 0);});
		assertThrows(IllegalArgumentException.class, () -> {gr.addEdge(1, 2, -5);});
		assertTrue(gr.addEdge(2, 2, 4));
		
	}
	
	@Test
	void removeEdge() {
		gr.addNode(1);
		gr.addNode(2);
		gr.addEdge(1, 2, 4);
		assertTrue(gr.removeEdge(1, 2));
	}
	
	
//-------------------------------PRUEBAS-FLOYD---------------------------------------
	@Test
	void floyd() {
		assertTrue(gr.addNode(1));
		assertTrue(gr.addNode(2));
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(4));
		assertTrue(gr.addNode(5));
		assertTrue(gr.addNode(6));
		assertTrue(gr.addNode(7));
		assertTrue(gr.addNode(8));
		assertTrue(gr.addEdge(1, 2, 2));
		assertTrue(gr.addEdge(2, 3, 5));
		assertTrue(gr.addEdge(3, 6, 6));
		assertTrue(gr.addEdge(6, 4, 6));
		assertTrue(gr.addEdge(4, 5, 7));
		assertTrue(gr.addEdge(5, 3, 3));
		assertTrue(gr.addEdge(5, 7, 2));
		assertTrue(gr.addEdge(7, 8, 1));
		assertTrue(gr.addEdge(1, 1, 1));
		assertTrue(gr.addEdge(1, 7, 8));
		assertTrue(gr.addEdge(7, 3, 9));
		assertTrue(gr.addEdge(5, 2, 2));
		assertTrue(gr.addEdge(8, 1, 4));
		assertTrue(gr.addEdge(2, 4, 3));
		assertTrue(gr.addEdge(8, 2, 7));
		assertTrue(gr.floyd());
		//System.out.println(gr.toString());
	}
	
	@Test
	void path() {
		assertTrue(gr.addNode(1));
		assertTrue(gr.addNode(2));
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(4));
		assertTrue(gr.addNode(5));
		assertTrue(gr.addNode(6));
		assertTrue(gr.addNode(7));
		assertTrue(gr.addNode(8));
		assertTrue(gr.addEdge(1, 2, 2));
		assertTrue(gr.addEdge(2, 3, 5));
		assertTrue(gr.addEdge(3, 6, 6));
		assertTrue(gr.addEdge(6, 4, 6));
		assertTrue(gr.addEdge(4, 5, 7));
		assertTrue(gr.addEdge(5, 3, 3));
		assertTrue(gr.addEdge(5, 7, 2));
		assertTrue(gr.addEdge(7, 8, 1));
		assertTrue(gr.addEdge(1, 1, 1));
		assertTrue(gr.addEdge(1, 7, 8));
		assertTrue(gr.addEdge(7, 3, 9));
		assertTrue(gr.addEdge(5, 2, 2));
		assertTrue(gr.addEdge(8, 1, 4));
		assertTrue(gr.addEdge(2, 4, 3));
		assertTrue(gr.addEdge(8, 2, 7));
		assertTrue(gr.floyd());
		assertEquals(gr.path(1, 7), "1	(8.0)	7");
		assertEquals(gr.path(2, 4), "2	(3.0)	4");
		assertEquals(gr.path(4, 8), "4	(7.0)	5	(2.0)	7	(1.0)	8");
		assertEquals(gr.path(3, 1), "3	(6.0)	6	(6.0)	4	(7.0)	5	(2.0)	7	(1.0)	8	(4.0)	1");
		assertEquals(gr.path(2, 3), "2	(5.0)	3");
	}
	
	@Test
	void recorridoProfundidad() {
		assertTrue(gr.addNode(1));
		assertTrue(gr.addNode(2));
		assertTrue(gr.addNode(3));
		assertTrue(gr.addNode(4));
		assertTrue(gr.addNode(5));
		assertTrue(gr.addNode(6));
		assertTrue(gr.addNode(7));
		assertTrue(gr.addNode(8));
		assertTrue(gr.addEdge(1, 2, 2));
		assertTrue(gr.addEdge(2, 3, 5));
		assertTrue(gr.addEdge(3, 6, 6));
		assertTrue(gr.addEdge(6, 4, 6));
		assertTrue(gr.addEdge(4, 5, 7));
		assertTrue(gr.addEdge(5, 3, 3));
		assertTrue(gr.addEdge(5, 7, 2));
		assertTrue(gr.addEdge(7, 8, 1));
		assertTrue(gr.addEdge(1, 1, 1));
		assertTrue(gr.addEdge(1, 7, 8));
		assertTrue(gr.addEdge(7, 3, 9));
		assertTrue(gr.addEdge(5, 2, 2));
		assertTrue(gr.addEdge(8, 1, 4));
		assertTrue(gr.addEdge(2, 4, 3));
		assertTrue(gr.addEdge(8, 2, 7));
		assertEquals(gr.recorridoProfundidad(1), "1	2	3	6	4	5	7	8");
		assertEquals(gr.recorridoProfundidad(2), "2	3	6	4	5	7	8	1");
		assertEquals(gr.recorridoProfundidad(3), "3	6	4	5	2	7	8	1");
		assertEquals(gr.recorridoProfundidad(4), "4	5	2	3	6	7	8	1");
		assertEquals(gr.recorridoProfundidad(5), "5	2	3	6	4	7	8	1");
		assertEquals(gr.recorridoProfundidad(6), "6	4	5	2	3	7	8	1");
		assertEquals(gr.recorridoProfundidad(7), "7	3	6	4	5	2	8	1");
		assertEquals(gr.recorridoProfundidad(8), "8	1	2	3	6	4	5	7");
	}
}
