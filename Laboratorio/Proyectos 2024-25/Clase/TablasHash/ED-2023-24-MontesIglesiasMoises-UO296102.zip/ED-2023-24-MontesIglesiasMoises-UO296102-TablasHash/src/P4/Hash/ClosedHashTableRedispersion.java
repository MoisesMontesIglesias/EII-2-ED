package P4.Hash;

/**
 * @author Profesores ED
 * @version 2023-24 distribuible
 *
 */
public class ClosedHashTableRedispersion<T> extends AbstractHash<T> {
// IMPORTANTE
//	No cambiar el nombre ni visibilidad de los atributos protected
	
	protected HashNode<T> tabla[]; 

	protected int hashSize;	// tama�o de la tabla, debe ser un numero primo
	protected int numElems;	// numero de elementos en la tabla en cada momento.

	public static final int LINEAL = 0;	// Tipo de exploracion en caso de colision, por defecto sera LINEAL
	public static final int CUADRATICA = 1;
	public static final int DOBLEHASH = 2;

	protected int exploracion; //exploracion que se realizara en caso de colision (LINEAL por defecto)

	private double minlf;
	private double maxlf;
	
	private static final double MINIMUN_LF = 0.16;
	private static final double MAXIMUN_LF = 0.5;

	/**
	 * Constructor para fijar el tamano al numero primo >= que el parametro y el tipo de exploración al indicado
	 * el tipo de exploracion(LINEAL=0, CUADRATICA=1, ...), si invalido LINEAL
	 */
	@SuppressWarnings("unchecked")
	public ClosedHashTableRedispersion(int tam, int expl) {
		hashSize=nextPrimeNumber(tam);// Establece un tama�o valido si tam no es primo
		
		tabla = (HashNode<T>[]) new HashNode[hashSize]; // Crea el array de HashNode's
//		if(!isPositivePrime(tam)) {
//			nextPrimeNumber(tam);
//		}
		if(expl == Double.POSITIVE_INFINITY) {
			exploracion = LINEAL;
		} else {
			exploracion = expl;
		}
		numElems = 0;
		for (int i = 0; i < hashSize; i++) {
			tabla[i] = new HashNode<T>();
		}

	}

	/**
	 * Constructor para fijar el tamaño al numero primo >= que el parametro
	 * Se le pasa el tamaño de la table Hash, si no es un numero primo lo ajusta al primo superior
	 * el factor de carga limite, por encima del cual hay que redispersar (directa)
	 * el factor de carga limite, por debajo del cual hay que redispersar (inversa)
	 * el tipo de exploracion(LINEAL=0, CUADRATICA=1, ...), si invalido LINEAL
	 */
	public ClosedHashTableRedispersion(int tam, double fcUP, double fcDOWN, int expl) {
		this(tam, expl);
		this.exploracion = expl;
		setMaxlf(fcUP);
		setMinlf(fcDOWN);
	}
	
	private void setMinlf(double minlf) {
		if(minlf < 0 || minlf > 1) {
			minlf = MINIMUN_LF;
		}
		this.minlf = minlf;
	}
	
	private void setMaxlf(double maxlf) {
		if(maxlf < 0 || maxlf > 1) {
			maxlf = MAXIMUN_LF;
		}
		this.maxlf = maxlf;
	}

	@Override
	public int getNumOfElems() {
		return numElems;
	}

	@Override
	public int getSize() {
		return tabla.length;
	}

	@Override
	public boolean add(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		if(numElems == tabla.length) {
			return false;
		}
		int intentos = 0;
		int posicion = funcionDeDispersion(elem, intentos);
		while(tabla[posicion].getStatus() == HashNode.LLENO) {
			posicion = funcionDeDispersion(elem, intentos++);
		}
		tabla[posicion].setInfo(elem);
		numElems++;
		reDispersion();
		return true;
	}
	
	public int funcionDeDispersion(T elem, int intentos) {
		int clave = fHash(elem);
		if(exploracion == LINEAL) {
			return (clave + intentos) % getSize();
		} else if(exploracion == CUADRATICA) {
			return (clave + intentos * intentos) % getSize();
		} else {
			return (clave + intentos * funcionSalto(elem)) % getSize(); //� f(x) = (h(x)+i * H2(x)) mod B			H2(x) = R � h(x) % R
		}
	}

	private int funcionSalto(T elem) {
		return previousPrimeNumber(getSize()) - fHash(elem) % previousPrimeNumber(getSize());
	}

	@Override
	public T find(T elem) {
		if(elem == null) {
			return null;
		}
		int intentos = 0;
		int posicion = funcionDeDispersion(elem, intentos);
		while ((tabla[posicion].getStatus() == HashNode.BORRADO) || (tabla[posicion].getStatus() == HashNode.LLENO && !(tabla[posicion].getInfo().equals(elem)))) {
			if(intentos == tabla.length || (tabla[posicion].getStatus() == HashNode.VACIO)) {
				return null;
			}
			posicion = funcionDeDispersion(elem, intentos++);
		}
		return elem;
	}

	@Override
	public boolean remove(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		if(find(elem) == null || numElems == 0){
			return false;
		}
		int intentos = 0;
		int posicion = funcionDeDispersion(elem, intentos);
		while(tabla[posicion].getStatus() != HashNode.VACIO) {
			if(tabla[posicion].getStatus() == HashNode.LLENO && tabla[posicion].getInfo().equals(elem)) {
				tabla[posicion].remove();
				numElems--;
				inverseReDispersion();
				return true;
			}
			posicion = funcionDeDispersion(elem, intentos++);
		}
		return false;
	}
	
	private double getLF() {
		return (double) getNumOfElems() / (double) hashSize;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected boolean reDispersion () {
		if(getLF() > maxlf) {
			HashNode<T>[] arrayBase = tabla;
			int tamAnterior = getSize();
			int tamNuevo = getSize() * 2;
			hashSize = nextPrimeNumber(tamNuevo);
			tabla = (HashNode<T>[]) new HashNode[hashSize];
			for (int i = 0; i < hashSize; i++) {
				tabla[i] = new HashNode<T>();
			}
			numElems = 0;
			for (int i = 0; i < tamAnterior; i++) {
				if(arrayBase[i].getStatus() == HashNode.LLENO) {
					add(arrayBase[i].getInfo());
				}
			}
			return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected boolean inverseReDispersion() {
		if(getLF() < minlf) {
			HashNode<T>[] arrayBase = tabla;
			int tamAnterior = getSize();
			int tamNuevo = getSize() / 2;
			hashSize = previousPrimeNumber(tamNuevo);
			tabla = (HashNode<T>[]) new HashNode[hashSize];
			for (int i = 0; i < hashSize; i++) {
				tabla[i] = new HashNode<T>();
			}
			numElems = 0;
			for (int i = 0; i < tamAnterior; i++) {
				if(arrayBase[i].getStatus() == HashNode.LLENO) {
					add(arrayBase[i].getInfo());
				}
			}
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString (){
		StringBuilder cadena=new StringBuilder();
		for (int i=0;i< getSize();i++){
			cadena.append(tabla[i]);
			cadena.append(";");
		}
		cadena.append("[Size: ");
		cadena.append(getSize());
		cadena.append(" Num.Elems.: ");
		cadena.append(getNumOfElems());
		cadena.append("]");
		return cadena.toString();
	}
}
