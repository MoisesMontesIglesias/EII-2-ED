package P2.grafos;

import java.text.DecimalFormat;


public class Grafos <T>{

	private double[][] weights;
	private boolean[][] edges;
	private T[] nodes;
	private int size;
	
	/*Algoritmo Floyd*/
	/****Matrices A y P****/
	private double [][] a;
	private int [][] p; // Posiciones de los nodos
	
	/*Cadena recorrido profundidad*/
	String cadenaDFS;
	
	@SuppressWarnings("unchecked")
	public Grafos (int dimension) {
		//Sale un warning porque el compilador no sabe el 
		this.weights = new double[dimension][dimension];
		this.edges = new boolean[dimension][dimension];
		this.nodes = (T[]) new Object[dimension];
		this.size = 0;
	}
	
	public int getSize() {
		return size;	
	}
	
	public int getNode(T node) {
		if(node == null) {
			return -1;
		}
		for (int i = 0; i < size; i++) {
			if(nodes[i].equals(node)) {
				return i;
			}
		}
		return -1;
	}
	
	public boolean addNode(T node) {
		if(existsNode(node)) {
			return false;
		}
		if(node == null) {
			throw new NullPointerException();
		}
		if(size > nodes.length){
			throw new FullStructureException(node);
		}
		nodes[size] = node;
		for (int i = 0; i <= size; i++) {
			weights[i][size] = 0;
			weights[size][i] = 0;
			edges[i][size] = false;
			edges[size][i] = false;
		}
		size++;
		return true;
	}
	
	public boolean existsNode(T node) {
		if (getNode(node) != -1) {
			return true;
		}
		return false;
	}
	
	public boolean removeNode(T node) {
		if(node == null) {
			throw new NullPointerException();
		}
		if(existsNode(node) == false) {
			return false;
		}
		int pos = getNode(node);
		size--;
		nodes[pos] = nodes[size];
		for(int i = 0; i < getSize(); i++) {
			edges[i][pos] = edges[size][i];
			edges[pos][i] = edges[i][size];
			weights[i][pos] = weights[size][i];
			weights[pos][i] = weights[i][size];
		}
		return true;
	}
	
	
	public boolean addEdge(T source, T target, double weight) {
		if(existsNode(source) == false) {
			throw new ElementNotPresentException(source);
		}
		if(existsNode(target) == false) {
			throw new ElementNotPresentException(target);
		}
		if(weight < 0) {
			throw new IllegalArgumentException();
		}
		if(existsEdge(source, target) == false) {
			weights[getNode(source)][getNode(target)] = weight;
			edges[getNode(source)][getNode(target)] = true;
			return true;
		} else if(existsEdge(source, target) == true) {
			return false;
		}
		return false;
	}
	
	public boolean existsEdge(T source, T target) {
		if(existsNode(source) == false || existsNode(target) == false) {
			return false;
		} else {
			return edges[getNode(source)][getNode(target)];
		}
	}
	
	public double getEdge(T source, T target) {
		if(existsNode(source) == false) {
			throw new ElementNotPresentException(source);
		}
		if(existsNode(target) == false) {
			throw new ElementNotPresentException(target);
		}
		if(existsEdge(source, target) == false) {
			return -1;
		} 
		return weights[getNode(source)][getNode(target)];
	}
	
	public boolean removeEdge(T source , T target) {
		if(existsNode(source) == false) {
			throw new ElementNotPresentException(source);
		}
		if(existsNode(target) == false) {
			throw new ElementNotPresentException(target);
		}
		if(existsEdge(source, target) == false) {
			return false;
		}else {
			edges[getNode(source)][getNode(target)] = false;
			weights[getNode(source)][getNode(target)] = 0;
			return true;
		}
	}
	
	private int getPivote(double[] vectorD, boolean[] nodesAlcanzados) {
		int pivote = -1;
		double elMenor = Double.POSITIVE_INFINITY;
		for (int i = 0; i < getSize(); i++) {
			if(vectorD[i] < elMenor && nodesAlcanzados[i] == false) {
				pivote = i;
				elMenor = vectorD[i];
			}
		}
		
		if(pivote == -1) {
			return pivote;
		}
		nodesAlcanzados[pivote] = true;
		return pivote;
	}
	
	public DijkstraDataClass dijkstra(T source) {
		DijkstraDataClass dj = new DijkstraDataClass(getSize(), 0);
		if(source == null || source.equals(null) || getNode(source) == -1) {
			return null;
		}
		int nodePosition = getNode(source);
		double[] vectorD = new double[getSize()];
		boolean[] nodesAlcanzados = new boolean[getSize()];
		int[] vectorP = new int[getSize()];
		for (int i = 0; i < getSize(); i++) {
			vectorP[i] = -1;
			if ( i == nodePosition) {
				vectorD[i] = 0;
			} else if(edges[nodePosition][i]) {
				vectorD[i] = weights[nodePosition][i];
			} else {
				vectorD[i] = Double.POSITIVE_INFINITY;
			}
		}
		dj.setdDijkstra(vectorD);
		dj.setpDijkstra(vectorP);
		nodesAlcanzados[nodePosition] = true;
		int w = getPivote(vectorD, nodesAlcanzados);
		while (w != -1) {
			nodesAlcanzados[w] = true;
			for(int i = 0; i < getSize(); i++) {
				if(edges[w][i] && !nodesAlcanzados[i] &&
						vectorD[w] + weights[w][i] < vectorD[i]) {
					vectorD[i] = vectorD[w] + weights[w][i];
					vectorP[i] = w;
				}
			}
			w = getPivote(vectorD, nodesAlcanzados);
		} 
		return dj;
	}

	public boolean floyd() {
		a = new double [getSize()][getSize()];
		p = new int [getSize()][getSize()];
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				p[i][j] = -1; //Hay que inicializar la matriz pFloyd a -1; 
							  // si lo edito posteriormente, sacarlo a dos for
				if(existsEdge(nodes[i], nodes[j])) {
					a[i][j] = weights[i][j];
				} else {
					a[i][j] = Double.POSITIVE_INFINITY;
				}
			}
			a[i][i] = 0;
		}
		
		for (int pivote = 0; pivote < getSize(); pivote++) { // pivote
			for (int o = 0; o < getSize(); o++) { //origen
				for (int d = 0; d < getSize(); d++) { //destino 
					//a[o][d] = minCostPath(nodes[p],nodes[d]); 
					if(a[o][pivote] + a[pivote][d] < a[o][d]) {
						a[o][d] = a[o][pivote] + a[pivote][d];
						p[o][d] = o;
					}
				}
			}
		}
		if(getSize() != 0) {
			return true;
		}
		return false;
	}

	public double minCostPath(T nodoOrigen, T nodoDestino) {
		if(!existsNode(nodoOrigen)) {
			throw new ElementNotPresentException(nodoOrigen);
		}
		if(!existsNode(nodoDestino)) {
			throw new ElementNotPresentException(nodoDestino);
		}
		floyd();
		return a[getNode(nodoOrigen)][getNode(nodoDestino)];
		
	}
	
	public String path(T origen, T destino) {
		//Casos raros/excepcionales
		if(!existsEdge(origen, destino)) {
			return origen + "\t" + (Double.POSITIVE_INFINITY)+ "\t" + destino + "\t";
		}
		if(origen.equals(destino)) {
			return origen + "\t";
		}
		if(!existsNode(origen) && !existsNode(destino)) {
			return "";
		}
		String path = origen.toString();
		System.out.println(path);
		recursivePath(getNode(origen), getNode(destino), path);
		path += "\t" + destino.toString() + "\t";
		System.out.println(path);
		return path;
	}
	
	private void recursivePath(int o, int d, String path){
		floyd();
		int pivote = p[o][d];
		while(pivote != -1) {
			path += ("\t" + pivote);
			System.out.println(path);
			pivote = p[o][d+1];
		}
		
	}
	
	public String recorridoProfundidad(T nodo) {
		String path = "";
		if (!existsNode(nodo)) {
			return "";
		}
		for (int i = 0; i < getSize(); i++) {
			
		}
		return path;
		
	}
	
	public double[][] getAFloyd() {
		return a;
	}
	
	public int[][] getPFloyd(){
		return p;
	}
	
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		String cadena = "";
		cadena += "NODOS\n";
		for (int i = 0; i < size; i++) {
			cadena += nodes[i].toString() + "\t";
		}
		cadena += "\n\nARISTAS\n";
		for (int i = 0; i <size; i++) {
			for (int j = 0; j < size; j++) {
					if (edges[i][j])
						cadena += "T\t";
					else
						cadena += "F\t";
			}
			cadena += "\n";
		}
		cadena += "\nPESOS\n";
		for (int i = 0; i <size; i++) {
			for (int j = 0; j < size; j++) {
				cadena += (edges[i][j]?df.format(weights[i][j]):"-") + "\t";
			}
			cadena += "\n";
		}
		return cadena;
	}
}
