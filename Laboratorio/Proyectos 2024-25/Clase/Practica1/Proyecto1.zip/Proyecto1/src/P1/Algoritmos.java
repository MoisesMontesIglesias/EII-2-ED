package P1;

public class Algoritmos {
	
	private static int a;
	
	private static int factorial(int n) {
		a = (n-1)*n;
		return a;
	}
	
	private static int fibonacci(int n) {
		for (int i = 2; i<n; i++) {
			
		}
		return a;
	}
	
	public static int iterativoFactorial(int n) {
		if(n == 0) {
			return 1;
		}else {
			for (int i = n; i>0; i--) {
				a += factorial(i);
			}
		}
		return a+1;
	}
	
	public static int recursivoFactorial(int n) {
		return n;
		
	}
	
	public static int iterativoPotencia(int n) {
		int m = n;
		while( n > 0) {
			a += m^(n-1)*m;
			n-=1;
		}
		return a+=1;
	}
	
	public static int recursivoPotencia(int n) {
		return n;
		
	}
	
	public static int iterativoFibonacci(int n) {
		if(n == 1) {
			return 0;
		} else if(n == 2){
			return 1;
		}else {
			for(int i = 2; i < n; i++) {
				fibonacci(i);
			}
			return a;
		}
		
		
	}
	
	public static int recursivoFibonacci(int n) {
		return 0;
		
	}
}
