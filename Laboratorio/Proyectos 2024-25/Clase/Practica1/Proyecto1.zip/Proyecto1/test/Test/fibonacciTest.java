package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class fibonacciTest {

	@Test
	public void test1() {
		assertEquals(Algoritmos.iterativoFibonacci(3),9);
		assertEquals(Algoritmos.iterativoFibonacci(3),9);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativoFibonacci(0),9);
		assertEquals(Algoritmos.iterativoFibonacci(0),9);
	}
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativoFibonacci(10),9);
		assertEquals(Algoritmos.iterativoFibonacci(10),9);
	}

}
