package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import P1.Algoritmos;

public class potenciaTest {

	
	@Test
	public void test1() {
		assertEquals(Algoritmos.iterativoPotencia(3),9);
		assertEquals(Algoritmos.recursivoPotencia(3),3);
	}
	
	@Test
	public void test2() {
		assertEquals(Algoritmos.iterativoPotencia(0),9);
		assertEquals(Algoritmos.recursivoPotencia(0),3);
	}
	
	
	@Test
	public void test3() {
		assertEquals(Algoritmos.iterativoPotencia(10),9);
		assertEquals(Algoritmos.recursivoPotencia(10),3);
	}
}
