package tablas.cerradas;

import static org.junit.Assert.*;

import org.junit.Test;

public class CloseHashTableTestPropios {
	
	@Test
	public void testRemoveWithString() {
		ClosedHashTable<Integer> a = new ClosedHashTable<>(5, 0);//LINEAL
		assertEquals(true, a.add(0));  // A�ado todos los elementos
		assertEquals(true, a.add(1));
		assertEquals(true, a.add(5));		
		assertEquals(true, a.add(4)); assertEquals(true, a.add(9));
		assertEquals("{0};{1};{5};{9};{4};[Size: 5 Num.Elems.: 5]", a.toString());
		  
		  
		
		assertThrows(NullPointerException.class, () -> {a.remove(null);}); // Borra null
		  
			  
		assertEquals("", a.removeWithString(1)); // Borra correctamente 
		
		assertEquals("",  a.removeWithString(1)); // Borra uno ya eliminado 
		assertEquals("", a.removeWithString(20)); //  Borra uno inexistente
		assertEquals("{0};{_D_};{5};{9};{4};[Size: 5 Num.Elems.: 4]", a.toString());
		  
		assertEquals("{0}{0}{_D_}", a.removeWithString(5)); // Borra correctamente un elemento desplazado por conflicto de posicion
		assertEquals("{4}{4}{0}{_D_}{_D_}", a.removeWithString(9));
		assertEquals("{0};{_D_};{_D_};{_D_};{4};[Size: 5 Num.Elems.: 2]", a.toString());
		  
		assertEquals("", a.removeWithString(0)); // Borra correctamente un elemento
		assertEquals("{_D_};{_D_};{_D_};{_D_};{4};[Size: 5 Num.Elems.: 1]",  a.toString());
		 
		 
	}
	
	@Test
	public void testSoloReDispersion() {
		//Crea una tabla del tama�o 4 (numero no primo)
		ClosedHashTableRedispersion<Integer> tabla = new ClosedHashTableRedispersion<Integer>(4,0.5, 0.16,0);  //Lineal
		//Muestra la tabla. Debera estar vacia y ser de tama�o 5
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};[Size: 5 Num.Elems.: 0]",tabla.toString());
				
		//Inserta elementos
		assertEquals(true,tabla.add(8));
		assertEquals(true,tabla.add(10));
		System.out.println(tabla.toString());
		assertEquals("{10};{_E_};{_E_};{8};{_E_};[Size: 5 Num.Elems.: 2]",tabla.toString());
		
		//Inserta y redispersi�n
		
		System.out.println ("Redispersion"); 
		assertEquals(true,tabla.add(66));
		System.out.println(tabla.toString());		
		assertEquals("{66};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{8};{_E_};{10};[Size: 11 Num.Elems.: 3]",tabla.toString());
		
		//Sigue insertando elementos
		assertEquals(true,tabla.add(77));
		System.out.println(tabla.toString());
		assertEquals("{66};{77};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{8};{_E_};{10};[Size: 11 Num.Elems.: 4]", tabla.toString());
		assertEquals(true,tabla.add(7));
						
		//Inserta y redispersi�n
		assertEquals(true,tabla.add(9));
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{77};{8};{9};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 6]",tabla.toString());
			
		//Borrar el 77
		assertEquals(true,tabla.remove(77));
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{_D_};{8};{9};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 5]",tabla.toString());
		
		//Borrar el 9
		assertEquals(true,tabla.remove(9));
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{_D_};{8};{_D_};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 4]",tabla.toString());
		
		//Borro un elmento que no existe
		assertEquals(false,tabla.remove(27));
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{_D_};{8};{_D_};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 4]",tabla.toString());

		
	}
	
	@Test
	public void testAddSearchRemove() {
		//Crea una tabla del tama�o 4 (numero no primo)
		ClosedHashTableRedispersion<Integer> tabla = new ClosedHashTableRedispersion<Integer>(4,0.5, 0.16,0);  //Lineal
		//Muestra la tabla. Debera estar vacia y ser de tama�o 5
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};[Size: 5 Num.Elems.: 0]",tabla.toString());
				
		//Inserta elementos
		assertEquals(true,tabla.addReDispersion(8));
		assertEquals(true,tabla.addReDispersion(10));
		System.out.println(tabla.toString());
		assertEquals("{10};{_E_};{_E_};{8};{_E_};[Size: 5 Num.Elems.: 2]",tabla.toString());
		
		//Inserta y redispersi�n
		
		System.out.println ("Redispersion"); 
		assertEquals(true,tabla.addReDispersion(66));
		System.out.println(tabla.toString());		
		assertEquals("{66};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{8};{_E_};{10};[Size: 11 Num.Elems.: 3]",tabla.toString());
		
		//Sigue insertando elementos
		assertEquals(true,tabla.addReDispersion(77));
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{8};{77};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 4]", tabla.toString());
		assertEquals(true,tabla.addReDispersion(7));
						
		//Inserta y redispersi�n
		assertEquals(true,tabla.addReDispersion(9));
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{8};{9};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{77};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};[Size: 47 Num.Elems.: 6]",tabla.toString());
			
		//Borrar el 77
		assertEquals(true,tabla.removeReDispersion(77));
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{8};{9};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 5]",tabla.toString());
		
		//Borrar el 9
		assertEquals(true,tabla.removeReDispersion(9));
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{8};{_D_};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 4]",tabla.toString());
		
		//Borro un elmento que no existe
		assertEquals(false,tabla.removeReDispersion(27));
		assertEquals("{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{8};{_D_};{10};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{66};{_E_};{_E_};[Size: 23 Num.Elems.: 4]",tabla.toString());
		
		//Borro el 10--> redispersi�n inversa
		assertEquals(true,tabla.removeReDispersion(10));
		System.out.println(tabla.toString());
		assertEquals("{66};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{8};{_E_};{_E_};[Size: 11 Num.Elems.: 3]",tabla.toString());
		
		assertEquals(true,tabla.removeReDispersion(66));
		System.out.println(tabla.toString());
		assertEquals("{_D_};{_E_};{_E_};{_E_};{_E_};{_E_};{_E_};{7};{8};{_E_};{_E_};[Size: 11 Num.Elems.: 2]",tabla.toString());
		
		assertEquals(true,tabla.removeReDispersion(8));
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{7};{_E_};{_E_};[Size: 5 Num.Elems.: 1]",tabla.toString());
		
		
		//Es el ultimo elemento. Nestor dice de no redispersar inversamente (no lo entiendo)
		assertEquals(true,tabla.removeReDispersion(7));
		System.out.println(tabla.toString());
		assertEquals("{_E_};{_E_};{_E_};[Size: 3 Num.Elems.: 0]",tabla.toString());
		
		
	}

}
