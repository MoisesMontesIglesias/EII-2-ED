package tablas.cerradas;


/**
 * @author Profesores ED
 * @version 2024-25 distribuible
 *
 */
public class ClosedHashTable<T> extends AbstractHash<T> {
// IMPORTANTE
//	No cambiar el nombre ni visibilidad de los atributos protected
	
	protected HashNode<T> tabla[]; 

	protected int hashSize;	// tamaño de la tabla, debe ser un numero primo
	protected int numElems;	// numero de elementos en la tabla en cada momento.

	public static final int LINEAL = 0;	// Tipo de exploracion en caso de colision, por defecto sera LINEAL
	public static final int CUADRATICA = 1;
	public static final int DOBLEHASH = 2;
	
	@SuppressWarnings("unused")
	private double maxLF;
	@SuppressWarnings("unused")
	private double minLF;

	protected int exploracion; //exploracion que se realizara en caso de colision (LINEAL por defecto)

	/**
	 * Constructor para fijar el tamano al numero primo >= que el parametro y el tipo de exploración al indicado
	 * el tipo de exploracion(LINEAL=0, CUADRATICA=1, ...), si invalido LINEAL
	 */
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int expl) {
		hashSize=nextPrimeNumber(tam);// Establece un tamaño valido si tam no es primo
		tabla = (HashNode<T>[]) new HashNode[hashSize]; // Crea el array de HashNode's
		numElems = 0;
		exploracion = expl;
		for (int i = 0; i < hashSize; i++) {
			tabla[i] = new HashNode<T>();
		}
		
	}

	/**
	 * Constructor para fijar el tamaño al numero primo >= que el parametro
	 * Se le pasa el tamaño de la table Hash, si no es un numero primo lo ajusta al primo superior
	 * el factor de carga limite, por encima del cual hay que redispersar (directa)
	 * el factor de carga limite, por debajo del cual hay que redispersar (inversa)
	 * el tipo de exploracion(LINEAL=0, CUADRATICA=1, ...), si invalido LINEAL
	 */
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, double fcUP, double fcDOWN, int expl) { // Para la segunda clase
		hashSize=nextPrimeNumber(tam);// Establece un tamaño valido si tam no es primo
		tabla = (HashNode<T>[]) new HashNode[hashSize]; // Crea el array de HashNode's
		numElems = 0;
		exploracion = expl;
		for (int i = 0; i < hashSize; i++) {
			tabla[i] = new HashNode<T>();
		}
		minLF = fcDOWN;
		maxLF = fcUP;
		
	}

	@Override
	public int getNumOfElems() {
		return numElems;
		
	}

	@Override
	public int getSize() {
		return tabla.length;
	}
	
	public int funcionDispersion(T elem, int intentos) {
		int clave = fHash(elem);
		if(exploracion == LINEAL) {
			return (clave + intentos) % getSize(); // f(x) = (h(x)+i) mod B
		} else if(exploracion == CUADRATICA) {
			return (clave + intentos * intentos) % getSize(); // f(x) = (h(x)+i2) mod B
		} else {
			return (clave + intentos * funcionSalto(elem)) % getSize(); //f(x) = (h(x)+i * H2(x)) mod B
		}
	}
	
	private int funcionSalto(T elem) {
		return previousPrimeNumber(getSize()) - fHash(elem) % previousPrimeNumber(getSize()); //H2(x) = R – h(x) % R
	}

	@Override
	public boolean add(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		if(numElems == tabla.length) {
			return false;
		}
		int intentos = 0;
		int posicion = funcionDispersion(elem, intentos);
		while(tabla[posicion].getStatus() == HashNode.LLENO) {
			posicion = funcionDispersion(elem, intentos++);
		}
		tabla[posicion].setInfo(elem);
		numElems++;
		reDispersion();
		return true;
	}

	@Override
	public T find(T elem) {
		if(elem == null) {
			return null;
		}
		int intentos = 0;
		int posicion = fHash(elem);
		int posTabla = tabla[posicion].getStatus();
		while(posTabla == HashNode.BORRADO || posTabla == HashNode.LLENO 
				&& !tabla[posicion].getInfo().equals(elem)) {
			if(intentos == tabla.length || posTabla == HashNode.VACIO) {
				return null;
			}
			posicion = funcionDispersion(elem, intentos++);
			posTabla = tabla[posicion].getStatus();
		}
		return elem;
	}

	@Override
	public boolean remove(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		if(find(elem) == null) {
			return false;
		}
		int intentos = 0;
		int posicion = fHash(elem);
		int posTabla = tabla[posicion].getStatus();
		while(posTabla != HashNode.VACIO) {
			if(posTabla == HashNode.LLENO && tabla[posicion].getInfo().equals(elem)) {
				tabla[posicion].remove();
				numElems--;
				inverseReDispersion();
				return true;
			}
			posicion = funcionDispersion(elem, intentos++);
			posTabla = tabla[posicion].getStatus();
		}
		return false;
	}

	@Override
	protected boolean reDispersion () {
		
		return false;
	}

	@Override
	protected boolean inverseReDispersion() {
		
		return false;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString (){
		StringBuilder cadena=new StringBuilder();
		for (int i=0;i< getSize();i++){
			cadena.append(tabla[i].toString());
			cadena.append(";");
		}
		cadena.append("[Size: ");
		cadena.append(getSize());
		cadena.append(" Num.Elems.: ");
		cadena.append(getNumOfElems());
		cadena.append("]");
		return cadena.toString();
	}
	
//-----------------------------------  Ejercicios propuestos  ----------------------------------------
	
	/**
	 *  Implementar un método remove que devuelva una cadena con el toString de todos los
	 *  elementos con los que se colisionó para su borrado
	 */
	public String removeWithString(T elem) {
		String path = "";
		if(elem == null) {
			throw new NullPointerException();
		}
		if(find(elem) == null) {
			return "";
		}
		int intentos = 0;
		int posicion = fHash(elem);
		int posTabla = tabla[posicion].getStatus();
		while(posTabla != HashNode.VACIO) {
			if(posTabla == HashNode.LLENO && tabla[posicion].getInfo().equals(elem)) {
				tabla[posicion].remove();
				numElems--;
				inverseReDispersion();
				return path;
			}
			path += tabla[posicion].toString();
			posicion = funcionDispersion(elem, intentos++);
			posTabla = tabla[posicion].getStatus();
		}
		return path;
	}

	/**
	 * Modificar el método add/search/remove para que cuando haya más de tres (o k)
	 * colisiones consecutivas se redisperse la tabla a un tamaño mayor.
	 */
	public boolean addReDispersion(T elem) {
		return true;
	}
	
	public boolean removeReDispersion(T elem) {
		return false;
	}
	
	public T findReDispersion(T elem) {
		return elem;
	}
}
