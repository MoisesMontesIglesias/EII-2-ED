package p3Arboles;

import java.util.ArrayList;
import java.util.List;

/**
* @author Prodesores ED (Español)
* @version 2024-25 distribuible
*/
public class BSTree <T extends Comparable<T>> extends AbstractTree <T>{
	
	private BSTNode<T> raiz = null;
	
	/**
	 * getter del nodo raiz del arbol
	 */
	protected BSTNode<T> getRoot() {
		return raiz;
	}
	
	
	/**
	 * Se le pasa el objeto comparable que hay que insertar
	 * devuelve true si lo inserta
	 * Si ya existe, no lo inserta y devuelve false (implementado mas tarde). 
	 * Si recibe un nodo nulo, no lo inserta y lanza una NullPointerException
	 */
	public boolean addNode(T nodo) {
		if(nodo == null) {
			throw new NullPointerException();
		}
		if(searchNode(nodo) != null) {
			return false;
		}
		if(raiz == null) {
			raiz = new BSTNode<T>(nodo);
		} else {
			addNodeRecursive(nodo, raiz);
		}
		return true;
	}
	
	
	private void addNodeRecursive(T actual, BSTNode<T> nodo) {
		BSTNode<T> left = nodo.getLeft();
		BSTNode<T> right = nodo.getRight();
		if(nodo.getInfo().compareTo(actual) > 0) {
			if(left == null) {
				nodo.setLeft(new BSTNode<T>(actual));
			} else {
				addNodeRecursive(actual, left);
			}
		} else {
			if(right == null)  {
				nodo.setRight(new BSTNode<T>(actual));
			} else {
				addNodeRecursive(actual, right);
			}
		}
		//nodo.updateBFHeight();
	}

	/**
	* Se le pasa un objeto comparable que se busca
	* Devuelve el objeto encontrado que cumple que es igual con el
	* buscado, null si no lo encuentra por cualquier motivo
	*/
	public BSTNode<T> searchNode(T nodo) {
		if(nodo == null || raiz == null) {
			return null;
		}
		return searchNodeRecursive(nodo, raiz);
	}
	
	
	private BSTNode<T> searchNodeRecursive(T nodo, BSTNode<T> actual) {
		if(actual == null) {
			return null;
		}
		if(actual.getInfo().equals(nodo)) {
			return actual;
		} else if(actual.getInfo().compareTo(nodo) > 0) {
			return searchNodeRecursive(nodo, actual.getLeft());
		} else {
			return searchNodeRecursive(nodo, actual.getRight());
		}
	}


	/**
	* Genera un String con el recorrido en pre-orden 
	* (toString de los nodos con un tabulador detras de cada nodo)
	*/
	public String preOrder() {
		return preOrdenR(raiz).strip();
		
	}
	
	private String preOrdenR(BSTNode<T> nodo) {
		String out = "";
		if(nodo!= null) {
			out+= nodo.getInfo() + "\t";
			out+= preOrdenR(nodo.getLeft());
			out+= preOrdenR(nodo.getRight());
		}
		return out;
	}


	/**
	* Genera un String con el recorrido en post-orden 
	* (toString de los nodos con un tabulador detras de cada nodo)
	*/
	public String postOrder() {
		return postOrderR(raiz).strip();
		
	}
	
	
	private String postOrderR(BSTNode<T> nodo) {
		String out = "";
		if(nodo!= null) {
			out+= postOrderR(nodo.getLeft());
			out+= postOrderR(nodo.getRight());
			out+= nodo.getInfo() + "\t";
		}
		return out;
	}


	/**
	* Genera un String con el recorrido en in-orden 
	* (toString de los nodos con un tabulador detras de cada nodo)
	*/
	public String inOrder() {
		return inOrderR(raiz).strip();
	}
	
	private String inOrderR(BSTNode<T> nodo) {
		String out = "";
		if(nodo!= null) {
			out+= inOrderR(nodo.getLeft());
			out+= nodo.getInfo() + "\t";
			out+= inOrderR(nodo.getRight());
		}
		return out;
	}
	
	
	/**
	* Se le pasa el objeto que se quiere borrar 
	* Si recibe un nodo nulo, lanza una NullPointerException
	* Devuelve true si lo ha borrado, false caso contrario
	*/
	public boolean removeNode (T node){
		if(node == null) {
			throw new NullPointerException();
		}
		if(searchNode(node) == null || raiz == null) {
			return false;
		}
		raiz = removeNodeRecursive(node, raiz);
		return true;
	}


	private BSTNode<T> removeNodeRecursive(T info, BSTNode<T> actual) {
		if(info.compareTo(actual.getInfo()) < 0) {
			actual.setLeft(removeNodeRecursive(info, actual.getLeft()));
		} else if(info.compareTo(actual.getInfo()) > 0) {
			actual.setRight(removeNodeRecursive(info, actual.getRight()));
		} else {
			if(actual.getLeft() == null) {
				return actual.getRight();
			} else if(actual.getRight() == null){
				return actual.getLeft();
			}
			actual.setInfo(getMaximo(actual.getLeft()));
			actual.setLeft(removeNodeRecursive(getMaximo(actual.getLeft()), actual.getLeft()));
		}
		return actual;
	}
	
	private T getMaximo(BSTNode<T> raiz) {
		return getMaximoRecursivo(raiz);
	}


	private T getMaximoRecursivo(BSTNode<T> raiz) {
		if(raiz.getRight() == null) {
			return raiz.getInfo();
		}
		return getMaximoRecursivo(raiz.getRight());
	}
	
//-------------------------------------  Ejercicios propuestos  ----------------------------------------

	public T getBrother(T element) {
		if(element == null) {
			throw new NullPointerException();
		}
		if(searchNode(element) == null) {
			return null;
		}
		if(element == getRoot().getInfo()) {
			return null;
		}
		return getBrotherRecursive(element, getRoot());
	}
	
	private T getBrotherRecursive(T nodo, BSTNode<T> actual) {
		BSTNode<T> left = actual.getLeft();
		BSTNode<T> right = actual.getRight();
		if(actual.getInfo().compareTo(nodo) > 0) {
			if(left.getInfo() == nodo) {
				if(right == null) {
					return null;
				}
				return actual.getRight().getInfo();
			} else {
				return getBrotherRecursive(nodo, actual.getLeft());
			}
		} else {
			if(right.getInfo() == nodo)  {
				if(left == null) {
					return null;
				}
				return actual.getLeft().getInfo();
			} else {
				return getBrotherRecursive(nodo, actual.getRight());
			}
		}
	}


	public List<T> getAncentors(T element){
		if(element == null) {
			return null;
		}
		if(searchNode(element) == null) {
			return null;
		}
		if(getRoot().getInfo() == element) {
			return null;
		}
		List<T> listaAncestors = new ArrayList<>();
		return getAncestorsRecursive(listaAncestors, getRoot(), element);
	}
	
	private List<T> getAncestorsRecursive(List<T> listaAncestors, BSTNode<T> actual, T nodo) {
		if(actual.getInfo().equals(nodo)) {
			return listaAncestors;
		} else if(actual.getInfo().compareTo(nodo) > 0) {
			listaAncestors.add(actual.getInfo());
			return getAncestorsRecursive(listaAncestors, actual.getLeft(), nodo);
		} else {
			listaAncestors.add(actual.getInfo());
			return getAncestorsRecursive(listaAncestors, actual.getRight(), nodo);
		}
	}


	public String preorderFromNodeString(T element) {
		if(element == null) {
			throw new NullPointerException();
		}
		if(searchNode(element) == null) {
			return "";
		}
		return preOrdenR(searchNode(element)).strip();
	}
	
	public List<T> preorderFromNodeList(T element){
		if(element == null) {
			throw new NullPointerException();
		}
		if(searchNode(element) == null) {
			return null;
		}
		List<T> listaNodos = new ArrayList<>();
		return preOrdenRLista(searchNode(element),listaNodos);
	}
	
	private List<T> preOrdenRLista(BSTNode<T> nodo, List<T> listaNodos) {
		if(nodo!= null) {
			listaNodos.add(nodo.getInfo());
			preOrdenRLista(nodo.getLeft(), listaNodos);
			preOrdenRLista(nodo.getRight(), listaNodos);
		}
		return listaNodos;
	}


	public int getNumNodes() {
		return preorderFromNodeList(getRoot().getInfo()).size();
	}
	
	public double getBFMean() {
		int countBF = 0;
		List<BSTNode<T>> lista = new ArrayList<BSTNode<T>>();
		lista = getNodes(getRoot(), lista);
		for (int i = 0; i < lista.size(); i++) {
		//	countBF += lista.get(i).getBF();
		}
		return (double) countBF / (double) getNumNodes();
	}
	
	private List<BSTNode<T>> getNodes(BSTNode<T> nodo, List<BSTNode<T>> listaNodos){
		if(nodo!= null) {
			listaNodos.add(nodo);
			getNodes(nodo.getLeft(), listaNodos);
			getNodes(nodo.getRight(), listaNodos);
		}
		return listaNodos;
	}
	
	public int getNumberOfLeaves() {
		int contador = 0;
		if(raiz == null) {
			return contador;
		}
		return numberOfLeavesRecursive(getRoot(), contador);
	}
	
	
	private int numberOfLeavesRecursive(BSTNode<T> nodo, int contador) {
		if(nodo != null && nodo.getLeft() == null && nodo.getRight() == null) {
			contador++;
		}
		if(nodo!= null) {
			contador = numberOfLeavesRecursive(nodo.getLeft(), contador);
			contador = numberOfLeavesRecursive(nodo.getRight(), contador);
		}
		return contador;
	}
	
	public BSTNode<T> union(BSTNode<T> other) {
		if(other == null && getRoot() == null) {
			return null;
		} else if(other == null) {
			return getRoot();
		} else if(getRoot() == null) {
			return other;
		}
		return unionRecursive(getRoot(), other);
	}
	
	private BSTNode<T> unionRecursive(BSTNode<T> root, BSTNode<T> other) {
		if(other != null) {
			addNode(other.getInfo());
			unionRecursive(root, other.getLeft());
			unionRecursive(root, other.getRight());
		}
		return other;
	}


	public BSTNode<T> intersection(BSTNode<T> other){
		if(other == null && getRoot() == null) {
			return null;
		} else if(other == null) {
			return getRoot();
		} else if(getRoot() == null) {
			return other;
		}
		BSTree<T> arbolNuevo = new BSTree<>();
		raiz = intersectionRecursive(getRoot(), other, arbolNuevo);
		return raiz;
	}
	
	private BSTNode<T> intersectionRecursive(BSTNode<T> root, BSTNode<T> other, BSTree<T> arbolNuevo) {
		if(other != null) {
			if(removeNode(other.getInfo()) == true){
				arbolNuevo.addNode(other.getInfo());
			}
			intersectionRecursive(root, other.getLeft(), arbolNuevo);
			intersectionRecursive(root, other.getRight(), arbolNuevo);
		}
		return arbolNuevo.getRoot();
	}

}