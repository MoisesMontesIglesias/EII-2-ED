package p3Arboles;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

// Test de prueba si el m�todo removeNode devuelve
// la raiz

public class ArbolesBinariosPruebasPropias{

	@Test
	public void test1()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(true,b.addNode(5));
		assertEquals(true,b.addNode(15));
		assertEquals(true,b.addNode(2));
		assertEquals(true,b.addNode(6));
		assertEquals(true,b.addNode(14));
		assertEquals(true,b.addNode(11));
		assertEquals(true,b.addNode(16));
		
		System.out.println(b.inOrder());
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 

		assertEquals(b.searchNode(16).getInfo(), b.getBrother(14));		
		assertEquals(null, b.getBrother(11));
		assertEquals(b.searchNode(2).getInfo(), b.getBrother(6));
		assertEquals(b.searchNode(5).getInfo(), b.getBrother(15));
		assertEquals(null, b.getBrother(10));
	 }
	
	@Test
	public void test2()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(true,b.addNode(5));
		assertEquals(true,b.addNode(15));
		List<Integer> listaAncestors = new ArrayList<Integer>();
		listaAncestors.add(10);
		assertEquals(listaAncestors, b.getAncentors(15));	
		assertEquals(true,b.addNode(2));
		assertEquals(true,b.addNode(6));
		listaAncestors.add(15);
		assertEquals(true,b.addNode(14));
		assertEquals(listaAncestors, b.getAncentors(14));
		assertEquals(true,b.addNode(11));
		listaAncestors.add(14);
		assertEquals(listaAncestors, b.getAncentors(11));
		assertEquals(true,b.addNode(16));
		
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 

	 }
	
	@Test
	public void test3()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(true,b.addNode(5));
		assertEquals(true,b.addNode(15));
		assertEquals(true,b.addNode(2));
		assertEquals(true,b.addNode(6));
		assertEquals(true,b.addNode(14));
		assertEquals(true,b.addNode(11));
		assertEquals(true,b.addNode(16));
		
		System.out.println(b.inOrder());
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 
		
		assertEquals("10\t5\t2\t6\t15\t14\t11\t16",b.preOrder());
		assertEquals("14\t11",b.preorderFromNodeString(14));
		assertEquals("15\t14\t11\t16",b.preorderFromNodeString(15));

	 }
	
	@Test
	public void test4()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(true,b.addNode(5));
		assertEquals(true,b.addNode(15));
		assertEquals(true,b.addNode(2));
		assertEquals(true,b.addNode(6));
		assertEquals(true,b.addNode(14));
		assertEquals(true,b.addNode(11));
		assertEquals(true,b.addNode(16));
		
		System.out.println(b.inOrder());
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 
		
		assertEquals("10\t5\t2\t6\t15\t14\t11\t16",b.preOrder());
		
		List<Integer> lista = new ArrayList<Integer>();
		lista.add(14); lista.add(11);
		assertEquals(lista, b.preorderFromNodeList(14));
		lista = new ArrayList<Integer>();
		lista.add(15); lista.add(14); lista.add(11); lista.add(16);
		assertEquals(lista, b.preorderFromNodeList(15));
	 }
	
	@Test
	public void test5()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(1,b.getNumberOfLeaves());
		assertEquals(true,b.addNode(5));
		assertEquals(1,b.getNumberOfLeaves());
		assertEquals(true,b.addNode(15));
		assertEquals(2,b.getNumberOfLeaves());
		assertEquals(true,b.addNode(2));
		assertEquals(2,b.getNumberOfLeaves());
		assertEquals(true,b.addNode(6));
		assertEquals(3,b.getNumberOfLeaves());
		assertEquals(true,b.addNode(14));
		assertEquals(true,b.addNode(11));
		assertEquals(true,b.addNode(16));
		assertEquals(4,b.getNumberOfLeaves());
		
		System.out.println(b.inOrder());
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 
	 }
	
	@Test
	public void test6()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(1, b.getNumNodes());
		assertEquals(true,b.addNode(5));
		assertEquals(2, b.getNumNodes());
		assertEquals(true,b.addNode(15));
		assertEquals(3, b.getNumNodes());
		assertEquals(true,b.addNode(2));
		assertEquals(4, b.getNumNodes());
		assertEquals(true,b.addNode(6));
		assertEquals(5, b.getNumNodes());
		assertEquals(true,b.addNode(14));
		assertEquals(6, b.getNumNodes());
		assertEquals(true,b.addNode(11));
		assertEquals(7, b.getNumNodes());
		assertEquals(true,b.addNode(16));
		assertEquals(8, b.getNumNodes());
		
		System.out.println(b.inOrder());
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 
	 }
	
	@Test
	public void test7()
	 {
		BSTree<Integer> b = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(1, b.getNumNodes());
		assertEquals(true,b.addNode(5));
		assertEquals(2, b.getNumNodes());
		assertEquals(true,b.addNode(15));
		assertEquals(3, b.getNumNodes());
		assertEquals(true,b.addNode(2));
		assertEquals(4, b.getNumNodes());
		assertEquals(true,b.addNode(6));
		assertEquals(5, b.getNumNodes());
		assertEquals(true,b.addNode(14));
		assertEquals(6, b.getNumNodes());
		assertEquals(true,b.addNode(11));
		assertEquals(7, b.getNumNodes());
		assertEquals(true,b.addNode(16));
		assertEquals(8, b.getNumNodes());
		
		System.out.println(b.inOrder());
		System.out.println (b.tumbarArbol(b.getRoot(), 3)); 
	 }
	
	@Test
	public void test8()
	 {
		BSTree<Integer> b = new BSTree<Integer>();
		BSTree<Integer> c = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(true,b.addNode(5));
		assertEquals(true,b.addNode(15));
		assertEquals(true,b.addNode(2));
		assertEquals(true,b.addNode(6));
		assertEquals(true,b.addNode(14));
		assertEquals(true,b.addNode(11));
		assertEquals(true,b.addNode(16));
		
		assertEquals(true,c.addNode(8));
		assertEquals(true,c.addNode(3));
		assertEquals(true,c.addNode(1));
		assertEquals(true,c.addNode(2));
		assertEquals(true,c.addNode(12));
		assertEquals(true,c.addNode(17));
		assertEquals(true,c.addNode(22));
		assertEquals(true,c.addNode(7));
		
		System.out.println(b.inOrder());
		System.out.println(b.tumbarArbol(b.getRoot(), 3)); 
		
		System.out.println(c.inOrder());
		System.out.println(c.tumbarArbol(b.getRoot(), 3)); 
		b.union(c.getRoot());
		b.tumbarArbol(b.getRoot(), 3);
		assertEquals("10\t5\t2\t1\t3\t6\t8\t7\t15\t14\t11\t12\t16\t17\t22",b.preOrder());
		
		System.out.println(b.inOrder());
		System.out.println(b.tumbarArbol(b.getRoot(), 3)); 
	 }
	
	@Test
	public void test9()
	 {
		BSTree<Integer> b = new BSTree<Integer>();
		BSTree<Integer> c = new BSTree<Integer>();

		// Borra en el �rbol vac�o
		assertEquals(false,b.removeNode(4));
		
		//Borra una clave null
		assertThrows(NullPointerException.class, () -> {b.removeNode(null);});
		
		
		assertEquals(true,b.addNode(10));
		assertEquals(true,b.addNode(5));
		assertEquals(true,b.addNode(15));
		assertEquals(true,b.addNode(2));
		assertEquals(true,b.addNode(6));
		assertEquals(true,b.addNode(22));
		assertEquals(true,b.addNode(11));
		assertEquals(true,b.addNode(16));
		
		assertEquals(true,c.addNode(8));
		assertEquals(true,c.addNode(3));
		assertEquals(true,c.addNode(1));
		assertEquals(true,c.addNode(2));
		assertEquals(true,c.addNode(12));
		assertEquals(true,c.addNode(17));
		assertEquals(true,c.addNode(22));
		assertEquals(true,c.addNode(7));
		
		System.out.println(b.inOrder());
		System.out.println(b.tumbarArbol(b.getRoot(), 3)); 
		
		System.out.println(c.inOrder());
		System.out.println(c.tumbarArbol(b.getRoot(), 3)); 
		b.intersection(c.getRoot());
		b.tumbarArbol(b.getRoot(), 3);
		assertEquals("2\t22",b.preOrder());
		
		System.out.println(b.inOrder());
		System.out.println(b.tumbarArbol(b.getRoot(), 3)); 
	 }
}