package p3ArbolesAVL;

import java.util.List;

import p3Arboles.BSTNode;

/**
* @author Prodesores ED (Español)
* @version 2024-25 distribuible
*/
public class AVLTree <T extends Comparable<T>> extends AbstractTree <T>{
	
	/**
	 * getter del nodo raiz del arbol
	 */
	protected AVLNode<T> getRoot() {
		return (AVLNode<T>) super.getRoot();
	}
	
	
	/**
	 * Se le pasa el objeto comparable que hay que insertar
	 * devuelve true si lo inserta
	 * Si ya existe, no lo inserta y devuelve false (implementado mas tarde). 
	 * Si recibe un nodo nulo, no lo inserta y lanza una NullPointerException
	 */
	public boolean addNode(T nodo) {
		if(nodo == null) {
			throw new NullPointerException();
		}
		if(searchNode(nodo) != null) {
			return false;
		}
		if(getRoot() == null) {
			setRoot(new AVLNode<T>(nodo));
		} else {
			setRoot(addNodeRecursive(nodo, getRoot()));
		}
		return true;
	}
	
	
	private AVLNode<T> addNodeRecursive(T actual, AVLNode<T> nodo) {
		AVLNode<T> left = nodo.getLeft();
		AVLNode<T> right = nodo.getRight();
		if(nodo.getInfo().compareTo(actual) > 0) {
			if(left == null) {
				nodo.setLeft(new AVLNode<T>(actual));
			} else {
				nodo.setLeft(addNodeRecursive(actual, left));
			}
		} else {
			if(right == null)  {
				nodo.setRight(new AVLNode<T>(actual));
			} else {
				nodo.setRight(addNodeRecursive(actual, right));
			}
		}
		return updateBFHeightBalanceo(nodo);
	}

	private AVLNode<T> updateBFHeightBalanceo(AVLNode<T> nodo) {
		nodo.updateBFHeight();
		if(nodo.getBF() == -2) {
			if(nodo.getLeft().getBF() == 1) {
				nodo = doubleLeftRotation(nodo);
			} else {
				nodo = singleLeftRotation(nodo);
			}
		} else if(nodo.getBF() == 2) {
			if(nodo.getRight().getBF() == -1) {
				nodo = doubleRightRotation(nodo);
			} else {
				nodo = singleRightRotation(nodo);
			}
		}
		return nodo;
	}

	private AVLNode<T> doubleRightRotation(AVLNode<T> nodo) {
		nodo.setRight(singleLeftRotation(nodo.getRight()));
		return singleRightRotation(nodo);
	}


	private AVLNode<T> doubleLeftRotation(AVLNode<T> nodo) {
		nodo.setLeft(singleRightRotation(nodo.getLeft()));
		return singleLeftRotation(nodo);
	}


	private AVLNode<T> singleLeftRotation(AVLNode<T> nodo) {
		AVLNode<T> aux = nodo.getLeft();
		nodo.setLeft(aux.getRight());
		nodo.updateBFHeight();
		aux.setRight(nodo); 
		aux.updateBFHeight();
		return aux;
	}
	
	private AVLNode<T> singleRightRotation(AVLNode<T> nodo) {
		AVLNode<T> aux = nodo.getRight();
		nodo.setRight(aux.getLeft());
		nodo.updateBFHeight();
		aux.setLeft(nodo);
		aux.updateBFHeight();
		return aux;
	}

	/**
	* Se le pasa un objeto comparable que se busca
	* Devuelve el objeto encontrado que cumple que es igual con el
	* buscado, null si no lo encuentra por cualquier motivo
	*/
	public AVLNode<T> searchNode(T nodo) {
		if(nodo == null || getRoot() == null) {
			return null;
		}
		return searchNodeRecursive(nodo, getRoot());
	}
	
	
	private AVLNode<T> searchNodeRecursive(T nodo, AVLNode<T> actual) {
		if(actual == null) {
			return null;
		}
		if(actual.getInfo().equals(nodo)) {
			return actual;
		} else if(actual.getInfo().compareTo(nodo) > 0) {
			return searchNodeRecursive(nodo, actual.getLeft());
		} else {
			return searchNodeRecursive(nodo, actual.getRight());
		}
	}


	/**
	* Genera un String con el recorrido en pre-orden 
	* (toString de los nodos con un tabulador detras de cada nodo)
	*/
	public String preOrder() {
		return preOrdenR(getRoot()).strip();
		
	}
	
	private String preOrdenR(AVLNode<T> nodo) {
		String out = "";
		if(nodo!= null) {
			out+= nodo.getInfo() + "\t";
			out+= preOrdenR(nodo.getLeft());
			out+= preOrdenR(nodo.getRight());
		}
		return out;
	}


	/**
	* Genera un String con el recorrido en post-orden 
	* (toString de los nodos con un tabulador detras de cada nodo)
	*/
	public String postOrder() {
		return postOrderR(getRoot()).strip();
		
	}
	
	
	private String postOrderR(AVLNode<T> nodo) {
		String out = "";
		if(nodo!= null) {
			out+= postOrderR(nodo.getLeft());
			out+= postOrderR(nodo.getRight());
			out+= nodo.getInfo() + "\t";
		}
		return out;
	}


	/**
	* Genera un String con el recorrido en in-orden 
	* (toString de los nodos con un tabulador detras de cada nodo)
	*/
	public String inOrder() {
		return inOrderR(getRoot()).strip();
	}
	
	private String inOrderR(AVLNode<T> nodo) {
		String out = "";
		if(nodo!= null) {
			out+= inOrderR(nodo.getLeft());
			out+= nodo.getInfo() + "\t";
			out+= inOrderR(nodo.getRight());
		}
		return out;
	}
	
	
	/**
	* Se le pasa el objeto que se quiere borrar 
	* Si recibe un nodo nulo, lanza una NullPointerException
	* Devuelve true si lo ha borrado, false caso contrario
	*/
	public boolean removeNode (T node){
		if(node == null) {
			throw new NullPointerException();
		}
		if(searchNode(node) == null || getRoot() == null) {
			return false;
		}
		setRoot(removeNodeRecursive(node, getRoot()));
		return true;
	}


	private AVLNode<T> removeNodeRecursive(T info, AVLNode<T> actual) {
		if(info.compareTo(actual.getInfo()) < 0) {
			actual.setLeft(removeNodeRecursive(info, actual.getLeft()));
		} else if(info.compareTo(actual.getInfo()) > 0) {
			actual.setRight(removeNodeRecursive(info, actual.getRight()));
		} else {
			if(actual.getLeft() == null) {
				return actual.getRight();
			} else if(actual.getRight() == null){
				return actual.getLeft();
			}
			actual.setInfo(getMaximo(actual.getLeft()));
			actual.setLeft(removeNodeRecursive(getMaximo(actual.getLeft()), actual.getLeft()));
		}
		return updateBFHeightBalanceo(actual);
	}
	
	private T getMaximo(AVLNode<T> raiz) {
		return getMaximoRecursivo(raiz);
	}


	private T getMaximoRecursivo(AVLNode<T> raiz) {
		if(raiz.getRight() == null) {
			return raiz.getInfo();
		}
		return getMaximoRecursivo(raiz.getRight());
	}

//-------------------------------------  Ejercicios propuestos  ----------------------------------------

	public T getBrother(T element) {
		return null;
	}
	
	public List<T> getAncentors(T element){
		return null;
	}
	
	public String preorderFromNodeString(T element) {
		return null;
	}
	
	public List<T> preorderFromNodeList(T element){
		return null;
	}
	
	public int getNumNodes() {
		return -1;
	}
		
	public double getBFMean() {
		return -1;
	}
	
	public int getNumberOfLeaves() {
		return -1;
	}
	
	public AVLTree<T> union(AVLTree<T> other) {
		return null;
	}
	
	public AVLTree<T> intersection(AVLTree<T> other){
		return null;
	}	
	
}