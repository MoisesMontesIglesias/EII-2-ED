package p3ArbolesAVL;

/**
 * Implementa un nodo de un arbol binario de busqueda con un objeto "Comparable" como informacion
 * @author Nestor
 * @version 2024-25
 * 
*/
public class AVLNode <T extends Comparable<T>> extends AbstractTreeNode<T>{

	private int height;
	private int BF;
	
	@SuppressWarnings("unchecked")
	public AVLNode(Comparable<T> info) {
		super((T) info);
	}

	/**
	 * @return El subarbol izquierdo
	 */
	public AVLNode<T> getLeft () {
		return (AVLNode<T>) super.getLeft();
	}

	/**
	 * @return El subarbol derecho
	 */
	public AVLNode<T> getRight () {
		return (AVLNode<T>) super.getRight();
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getBF() {
		return BF;
	}

	public void setBF(int bF) {
		BF = bF;
	}
	
	public void updateBFHeight() {
		int HD = 0;
		int HI = 0;
		if(getRight() != null) {
			HD = getRight().getHeight() + 1;
		}
		// else{
		//	HD = 0;
	    //}
		if(getLeft() != null) {
			HI = getLeft().getHeight() + 1;
		}
		// else{
		//	HI = 0;
		//}
		setBF(HD - HI);
		setHeight(Integer.max(HD, HI));
	}
	
	public String toString() {
		return getInfo().toString() + ":BF=" + BF;
	}
}
