package p3ArbolesAVL;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

class AVLTest {

	@Test
	void test() {
		AVLTree<Integer> b = new AVLTree<Integer>();
		assertTrue(b.addNode(7));
		System.out.println(b.inOrder());
//		System.out.println(b.toString());
		assertTrue(b.addNode(6));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(5));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(4));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(3));
//		System.out.println(b.toString());
		System.out.println(b.inOrder());
		assertTrue(b.addNode(2));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(1));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(8));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(9));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(10));
		System.out.println(b.inOrder());
//		System.out.println(b.toString());
	}

	@Test
	void test2() {
		AVLTree<Integer> b = new AVLTree<Integer>();
		assertTrue(b.addNode(5));
		System.out.println(b.inOrder());
//		System.out.println(b.toString());
		assertTrue(b.addNode(2));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(10));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(15));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(12));
//		System.out.println(b.toString());
		System.out.println(b.inOrder());
		assertTrue(b.addNode(9));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(7));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(8));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(6));
		System.out.println(b.inOrder());
		System.out.println(b.toString());
	}
	
	@Test
	void test3() {
		AVLTree<Integer> b = new AVLTree<Integer>();
		assertTrue(b.addNode(4));
		System.out.println(b.inOrder());
//		System.out.println(b.toString());
		assertTrue(b.addNode(2));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(1));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(3));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(8));
//		System.out.println(b.toString());
		System.out.println(b.inOrder());
		assertTrue(b.addNode(6));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(5));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(7));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(10));
		System.out.println(b.inOrder());
		assertTrue(b.addNode(11));
		System.out.println(b.inOrder());
		System.out.println(b.toString());
		assertTrue(b.removeNode(1));
		System.out.println(b.inOrder());
		assertTrue(b.removeNode(3));
		System.out.println(b.inOrder());
		assertTrue(b.removeNode(4));
		System.out.println(b.inOrder());
		assertTrue(b.removeNode(7));
		System.out.println(b.inOrder());
		assertTrue(b.removeNode(11));
		System.out.println(b.inOrder());
		assertTrue(b.removeNode(10));
		System.out.println(b.inOrder());
		System.out.println(b.toString());
	}
}
