package p3ColasPrioridad;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestAlumnos {

//	@Test
//	void addTest() {
//		EDBinaryHeap<Integer> x = new EDBinaryHeap<>(25);
//		assertTrue(x.add(60));
//		System.out.println(x.toString());
//		assertTrue(x.add(40));
//		System.out.println(x.toString());
//		assertTrue(x.add(80));
//		System.out.println(x.toString());
//		assertTrue(x.add(20));
//		System.out.println(x.toString());
//		assertTrue(x.add(55));
//		System.out.println(x.toString());
//		assertTrue(x.add(65));
//		System.out.println(x.toString());
//		assertTrue(x.add(63));
//		System.out.println(x.toString());
//		assertTrue(x.add(51));
//		System.out.println(x.toString());
//		assertTrue(x.add(75));
//		System.out.println(x.toString());
//		assertTrue(x.add(2));
//		System.out.println(x.toString());
//		assertTrue(x.add(4));
//		System.out.println(x.toString());
//		assertTrue(x.add(90));
//		System.out.println(x.toString());
//		assertTrue(x.add(95));
//		System.out.println(x.toString());
//		assertTrue(x.add(99));
//		System.out.println(x.toString());
//		assertTrue(x.add(41));
//		System.out.println(x.toString());
//		assertTrue(x.add(42));
//		System.out.println(x.toString());
//		assertTrue(x.add(50));
//		System.out.println(x.toString());
//		assertTrue(x.add(22));
//		System.out.println(x.toString());
//		assertTrue(x.add(30));
//		System.out.println(x.toString());
//		assertTrue(x.add(25));
//		System.out.println(x.toString());
//		assertTrue(x.add(31));
//		System.out.println(x.toString());
//		assertTrue(x.add(32));
//		System.out.println(x.toString());
//		assertTrue(x.add(33));
//		System.out.println(x.toString());
//		assertTrue(x.add(36));
//		System.out.println(x.toString());
//		assertTrue(x.add(38));
//		System.out.println(x.toString());
//		assertFalse(x.add(39));
//		System.out.println(x.toString());
//	}
//	@Test
//	void pollTest() {
//		EDBinaryHeap<Integer> x = new EDBinaryHeap<>(25);
//		assertTrue(x.add(60));
//		System.out.println(x.toString());
//		assertTrue(x.add(40));
//		System.out.println(x.toString());
//		assertTrue(x.add(80));
//		System.out.println(x.toString());
//		assertTrue(x.add(20));
//		System.out.println(x.toString());
//		assertTrue(x.add(55));
//		System.out.println(x.toString());
//		assertTrue(x.add(65));
//		System.out.println(x.toString());
//		assertTrue(x.add(63));
//		System.out.println(x.toString());
//		assertTrue(x.add(51));
//		System.out.println(x.toString());
//		assertTrue(x.add(75));
//		System.out.println(x.toString());
//		assertTrue(x.add(2));
//		System.out.println(x.toString());
//		assertTrue(x.add(4));
//		System.out.println(x.toString());
//		assertTrue(x.add(90));
//		System.out.println(x.toString());
//		assertTrue(x.add(95));
//		System.out.println(x.toString());
//		assertTrue(x.add(99));
//		System.out.println(x.toString());
//		assertTrue(x.add(41));
//		System.out.println(x.toString());
//		assertTrue(x.add(42));
//		System.out.println(x.toString());
//		assertTrue(x.add(50));
//		System.out.println(x.toString());
//		assertTrue(x.add(22));
//		System.out.println(x.toString());
//		assertTrue(x.add(30));
//		System.out.println(x.toString());
//		assertTrue(x.add(25));
//		System.out.println(x.toString());
//		assertTrue(x.add(31));
//		System.out.println(x.toString());
//		assertTrue(x.add(32));
//		System.out.println(x.toString());
//		assertTrue(x.add(33));
//		System.out.println(x.toString());
//		assertTrue(x.add(36));
//		System.out.println(x.toString());
//		assertTrue(x.add(38));
//		System.out.println(x.toString());
//		assertFalse(x.add(39));
//	}
//
//	@Test
//	void removeTest() {
//		EDBinaryHeap<Integer> x = new EDBinaryHeap<>(25);
//		assertTrue(x.add(60));
//		System.out.println(x.toString());
//		assertTrue(x.add(40));
//		System.out.println(x.toString());
//		assertTrue(x.add(80));
//		System.out.println(x.toString());
//		assertTrue(x.add(20));
//		System.out.println(x.toString());
//		assertTrue(x.add(55));
//		System.out.println(x.toString());
//		assertTrue(x.add(65));
//		System.out.println(x.toString());
//		assertTrue(x.add(63));
//		System.out.println(x.toString());
//		assertTrue(x.add(51));
//		System.out.println(x.toString());
//		assertTrue(x.add(75));
//		System.out.println(x.toString());
//		assertTrue(x.add(2));
//		System.out.println(x.toString());
//		assertTrue(x.add(4));
//		System.out.println(x.toString());
//		assertTrue(x.add(90));
//		System.out.println(x.toString());
//		assertTrue(x.add(95));
//		System.out.println(x.toString());
//		assertTrue(x.add(99));
//		System.out.println(x.toString());
//		assertTrue(x.add(41));
//		System.out.println(x.toString());
//		assertTrue(x.add(42));
//		System.out.println(x.toString());
//		assertTrue(x.add(50));
//		System.out.println(x.toString());
//		assertTrue(x.add(22));
//		System.out.println(x.toString());
//		assertTrue(x.add(30));
//		System.out.println(x.toString());
//		assertTrue(x.add(25));
//		System.out.println(x.toString());
//		assertTrue(x.add(31));
//		System.out.println(x.toString());
//		assertTrue(x.add(32));
//		System.out.println(x.toString());
//		assertTrue(x.add(33));
//		System.out.println(x.toString());
//		assertTrue(x.add(36));
//		System.out.println(x.toString());
//		assertTrue(x.add(38));
//		System.out.println(x.toString());
//		assertFalse(x.add(39));
//		System.out.println(x.toString());
//		assertTrue(x.remove(99));
//		assertTrue(x.remove(60));
//		assertTrue(x.remove(32));
//		assertTrue(x.remove(2));
//	}
	@Test
	void removeTest2() {
		EDBinaryHeap<Integer> b = new EDBinaryHeap<>(25);
		//Caso 3: Filtrado ascendente
				assertEquals(true, b.add(1));
				System.out.println(b.toString());
				assertEquals(true, b.add(2));
				System.out.println(b.toString());
				assertEquals(true, b.add(7));
				System.out.println(b.toString());
				assertEquals(true, b.add(4));
				System.out.println(b.toString());
				assertEquals(true, b.add(3));
				System.out.println(b.toString());
				assertEquals(true, b.add(9));
				System.out.println(b.toString());
				assertEquals(true, b.add(8));
				System.out.println(b.toString());
				assertEquals(true, b.add(5));
				System.out.println(b.toString());
				assertEquals("1	2	7	4	3	9	8	5",b.toString() );
				assertEquals(true, b.remove(8));
				assertEquals("1	2	5	4	3	9	7",b.toString() );
	}
}
