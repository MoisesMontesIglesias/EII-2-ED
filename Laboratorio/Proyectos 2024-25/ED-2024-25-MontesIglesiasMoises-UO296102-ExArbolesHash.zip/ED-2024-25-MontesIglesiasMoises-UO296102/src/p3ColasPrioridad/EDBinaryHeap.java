package p3ColasPrioridad;

import java.util.Iterator;
import java.util.List;

import p3Arboles.BSTNode;
import p3ArbolesAVL.AVLNode;

/**
 * @author Profesores ED
 * @version 2024-25 distribuible
 */
 public class EDBinaryHeap<T extends Comparable<T>> implements EDPriorityQueue<T>{
	protected T [] elementos;
	protected int numElementos;

	
	public EDBinaryHeap(int numMaxElementos) {
		elementos = (T[]) new Comparable[numMaxElementos];
		numElementos = 0;
	}

	@Override
	public boolean add(T info) {
		if(info == null) {
			throw new NullPointerException("El parámetro es null");
		}
		if(numElementos >= elementos.length) {
			return false;
		}
		elementos[numElementos] = info;
		filtradoAscendente(numElementos);
		numElementos++;
		return true;
	}

	@Override
	public T poll() {
		if(isEmpty()) {
			return null;
		}
		T sacar = elementos[0];
		numElementos--;
		elementos[0] = elementos[numElementos];
		filtradoDescendente(0);
		return sacar;
	}

	@Override
	public boolean remove(T info) {
		if(info == null) {
			throw new NullPointerException("El parámetro es null");
		}
		if(isEmpty()) {
			return false;
		}
		int posInfo = searchElement(info);
		if(posInfo == -1) {
			return false;
		} 
		numElementos--;	
		elementos[posInfo] = elementos[numElementos];
		comprobarFiltrado(posInfo);
		return true;
	}
	
	private void comprobarFiltrado(int posInfo) {
		int posPadre = (posInfo - 1) / 2;
	    if (posInfo > 0 && elementos[posInfo].compareTo(elementos[posPadre]) < 0) {
	        filtradoAscendente(posInfo);
	    } else {
	        filtradoDescendente(posInfo);
	    }
	}

	@Override
	public boolean isEmpty() {
		if(numElementos == 0) {
			return true;
		}
		return false;
	}

	@Override
	public void clear() {
		numElementos = 0;
	}

	/**  
	 * Devuelve una cadena con la informacion de los elementos que contiene el  
	 * monticulo separados por tabuladores
	*/
	@Override
	public String toString() {
		String path = "";
		for (int i = 0; i < numElementos; i++) {
			path += elementos[i] + "\t";
		}
		return path.strip();
	}

	@Override
	public boolean cambiarPrioridad(int pos, T elemento) {
		if(elemento == null) {
			throw new NullPointerException();
		}
		if (pos < 0 || pos >= numElementos) {
	        return false;
	    }
	    T aux = elementos[pos];
	    elementos[pos] = elemento;
	    if (elemento.compareTo(aux) > 0) {
	    	filtradoDescendente(pos);
	    } else if (elemento.compareTo(aux) < 0) {
	    	filtradoAscendente(pos);
	    }
	    return true;
	}
    

    /**
     * Realiza una filtrado ascendente de minimos en el monticulo
     * 
     * Se le pasa el indice del elemento a filtrar
     */
    protected void filtradoAscendente(int posHijo) {
    	int posPadre = (posHijo - 1) / 2;
    	while(elementos[posPadre].compareTo(elementos[posHijo]) > 0) {
    		T aux = elementos[posPadre];
    		elementos[posPadre] = elementos[posHijo];
    		elementos[posHijo] = aux;
    		posHijo = posPadre;
    		posPadre = (posHijo - 1) / 2;
    	}
    }

    /**
     * Realiza una filtrado descendente de minimos en el monticulo
     * 
     * Se le pasa el indice del elemento a filtrar
     */
    protected void filtradoDescendente(int posPadre) {
    	if(posPadre == -1) {
    		return;
    	}
    	int posMenorHijos = getMinHijo(posPadre);
    	if(posMenorHijos == -1) {
    		return;
    	}
    	while(elementos[posMenorHijos].compareTo(elementos[posPadre]) < 0) {
    		T aux = elementos[posPadre];
    		elementos[posPadre] = elementos[posMenorHijos];
    		elementos[posMenorHijos] = aux;
    		posPadre = posMenorHijos;
    		posMenorHijos = getMinHijo(posPadre);
    		if(posMenorHijos == -1) {
    			break;
    		}
    	}
    }
	
	/**
	 * Metodo que calcula y devuelve la posicion del hijo menor del nodo pasado
	 * como parametro.
	 * 
	 * @param pos  La posicion del nodo padre
	 * @return  La posicion del menor de sus hijos o -1 si no existe ninguno
	 */
	private int getMinHijo(int posPadre) {
		int posHijoIzq = 2 * posPadre + 1;
    	int posHijoDer = 2 * posPadre + 2;
    	if(posHijoIzq >= numElementos) {
    		return -1;
    	} else if(posHijoDer >= numElementos && posHijoIzq < numElementos) {
    		return posHijoIzq;
    	} else if((elementos[posHijoIzq].compareTo(elementos[posHijoDer]) <= 0)) {
    		return posHijoIzq;
    	} else {
    		return posHijoDer;
    	}
	}

	public int searchElement(T info) {
		if(info == null) {
			return -1;
		}
		for (int i = 0; i < numElementos; i++) {
			if(elementos[i].equals(info)) {
				return i;
			}
		}
		return -1;
	}
	
//-------------------------------------  Ejercicios propuestos  ----------------------------------------
	
	public List<T> getAncentors(T element){
		return null;
	}
	
	public String preorderFromNodeString(T element) {
		return null;
	}
	
	public List<T> preorderFromNodeList(T element){
		return null;
	}
	
	public String preOrder() {
	    if (isEmpty()) {
	        return "";
	    }
	    return preOrdenR(0).strip(); 
	}

	private String preOrdenR(int pos) {
	    if (pos >= numElementos) {
	        return "";
	    }
	    String resultado = elementos[pos] + "\t";
	    int posHijoIzq = 2 * pos + 1;
	    resultado += preOrdenR(posHijoIzq);
	    int posHijoDer = 2 * pos + 2;
	    resultado += preOrdenR(posHijoDer);
	    return resultado;
	}
		
	public int getNumNodes() {
		return -1;
	}
 }
