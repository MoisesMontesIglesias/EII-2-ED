package p1Algoritmia;

public class Algorithms {
	private static final long SLEEP_TIME = 1;

	public static void doNothing() {
		try {
			Thread.sleep(SLEEP_TIME);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Completad con los metodos que se os pidan...
	public long factorial (int n) { // Calcula el factorial de n>=0 de forma recursiva 
		if (n<0) 
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		if(n!=0) {
			return n * factorial(n-1); //Si es el caso general
		}
		return 1; //Si es el caso base
	} 
	public int fibonacci (int n) { // Calcula el termino n-esimo teniendo en cuenta que el primer término se considera fib(0)=0; y fib(1)=1 
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		//Casos base
		if(n == 0) {
			return 0;
		} else if(n == 1) {
			return 1; 
		}
		return fibonacci(n-2) + fibonacci(n-1); //Si es el caso general

	} 
	// para pruebas de que produce una excepción... 
	//   assertThrows(IllegalArgumentException.class, () -> {al.factorial(-1);}); 

	public long pow2Rec1(int n) {  // calcula 2 elevado a n de forma recursiva 2^n = 2*2^(n-1) 
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		if(n == 0) {
			return 1;
		}
		if(n != 1) {
			return 2*pow2Rec1(n-1);
		} else {
			return 2;
		}
	} 
	
	public long potenciaRec(int n, int m) { // Calcula a elevado a b de forma recursiva por potencias sucesivas
		if (n < 0 || m < 0) {
			throw new IllegalArgumentException("No permitido alguno de los parámetros introducido"); 
		}
		if(m == 0) {
			return 1;
		}
		if(m != 1) {
			return n*potenciaRec(n, m-1);
		} else {
			return n;
		}
	} 
	
	public long restoDivRec(int n, int m) { // calcula el resto de la división a/b de forma recursiva 
		if (n < 0 || m <= 0) {
			throw new IllegalArgumentException("No permitido alguno de los parámetros introducido"); 
		}
		if(n >= m) {
			return restoDivRec(n-m, m);
		}
		return n;
	}
	
	public long divEntRec(int n, int m) { //calcula la división entera a/b de forma recursiva 
		if (n < 0 || m <= 0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos"); 
		}
		return divEntRec2(n, m, 0);
	}
	
	private int divEntRec2(int n, int m, int contador) {
		if(n >= m) {
			return divEntRec2(n-m, m, contador+1);
		}
		return contador;
	}

	public long invertirEnteroRec(int n) { // Invierte un entero invertirEnteroRec(1234)=4321 de forma recursiva 
		if (n<0) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		return invertirEnteroRec2(n, 0);
	}

	private long invertirEnteroRec2(int n, int nuevo) {
		if(n <= 0) {
			return nuevo;
		} 
		int x = n/10;
		int y = n%10;
		String z = String.valueOf(nuevo);
		return invertirEnteroRec2(x,Integer.parseInt(z+y));
	}

	public String invertirStringRec(String n) { // Invierte un string de forma recursiva invertirStringRec("abc")="cba"
		if (n == null) {
			throw new IllegalArgumentException("No permitidos parámetros negativos como "+ n); 
		}
		return invertirStringRec2(n, "");
	}
	
	private String invertirStringRec2(String n, String nuevo) {
		if(n.length() <= 0 || n.isBlank() || n.isEmpty()) {
			return nuevo;
		}
		String x = nuevo+n.substring(n.length()-1);
		String y = n.substring(0,n.length()-1);
		return invertirStringRec2(y,x);
	}

	public boolean esSimetricaRec(int[][] m) {  // Indica si es simétrica una matriz cuadrada de forma recursiva 
		if(m == null) {
			throw new IllegalArgumentException("No permitidos parámetros nulos"); 
		}
		return esSimetricaRec2(m, 0, 0);
	}

	private boolean esSimetricaRec2(int[][] m, int i, int j) {
		if(j == m[0].length) {
			return true;
		}
		if(m[i][j] == m[j][i]) {
			i+=1;
			if(i == m.length) {
				return esSimetricaRec2(m, 0, j+1);
			}
			return esSimetricaRec2(m,i, j);
		}
		return false;
	}
}
